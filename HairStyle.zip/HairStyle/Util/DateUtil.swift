//
//  DateUtil.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/29.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class DateUtil {
    static let dateTimeFormat = "yyyy-MM-dd HH:mm:ss"
    static let daySec = DateUtil.hourSec * 24
    static let hourSec = 60 * 60
    
    //年齢を計算
    static func age(birthday: Date) -> Int {
        let nowDateInt = Int(Date().string(format: "yyyyMMdd"))
        let birthdayInt = Int(birthday.string(format: "yyyyMMdd"))
        return (nowDateInt! - birthdayInt!) / 10000
    }
    
    //月の日数を計算
    static func endDay(year: Int, month: Int) -> Int {
        let date = Date(year: year, month: month)
        let calendar = NSCalendar(identifier: NSCalendar.Identifier.gregorian)!
        let range = calendar.range(of: .day, in: .month, for: date)
        return range.length
    }
    
    static func isEndMonth() -> Bool {
        return DateUtil.endDay(year: Date().year, month: Date().month) == Date().day
    }
    static func isEndYear() -> Bool {
        return (Date().month == 12) && isEndMonth()
    }
    
    
    static func dateFromString(string: String, format: String) -> NSDate {
        let formatter: DateFormatter = DateFormatter()
        formatter.calendar = NSCalendar(identifier: NSCalendar.Identifier.gregorian) as Calendar?
        formatter.dateFormat = format
        return formatter.date(from: string)! as NSDate
    }
    
    static func stringFromDate(date: NSDate, format: String) -> String {
        let formatter: DateFormatter = DateFormatter()
        formatter.calendar = NSCalendar(identifier: NSCalendar.Identifier.gregorian) as Calendar?
        formatter.dateFormat = format
        return formatter.string(from: date as Date)
    }
//    static func getDayAocca(starttime: NSDate) -> AoccaType {
//        let calendar = NSCalendar(identifier: NSCalendar.Identifier.gregorian) as Calendar?
//        let isToday = calendar?.isDateInToday(starttime as Date)
//        debugLog(isToday)
//        if isToday == false {
//            let isTomorrow = calendar?.isDateInTomorrow (starttime as Date)
//            debugLog(isTomorrow)
//        }
//        return AoccaType.noaocca
//    }
    
    // aocca判定
//    static func getAoccaType(startunixtime: Int?,endunixtime: Int?) -> AoccaType {
//        if startunixtime == nil || endunixtime == nil {
//            return AoccaType.noaocca
//        }
//        let now:Int = Int(NSDate().timeIntervalSince1970)
//        if  now <= endunixtime! {
////        if now >= startunixtime! && now <= endunixtime! {
//            return AoccaType.aocca
//        }
//        return AoccaType.noaocca
//    }
    
    static func getCountDownMinuites(endunixtime: Int?) -> String {
        if endunixtime == nil {
            return String("")
        }
        let enddate:NSDate = NSDate(timeIntervalSince1970: Double(endunixtime!))
        let hours:Int = Calendar.current.dateComponents([.hour], from: Date(), to: enddate as Date).hour ?? 0
        let minuites:Int = Calendar.current.dateComponents([.minute], from: Date(), to: enddate as Date).minute ?? 0
        var limitStr:String = "\n"+"remaining".localized+" \(hours)"+"hours".localized+"\(minuites-hours*60)"+"minute".localized
        if hours == 0 {
            limitStr = "\n"+"remaining".localized+" \(minuites)"+"minute".localized
        }
        return limitStr
    }
    /// 曜日取得する
    static func dayOfWeek(date: Date) -> String {
        let weekArray : [String] = ["日", "月", "火", "水", "木", "金", "土"]
        let weekStr : String = weekArray[Calendar.current.component(Calendar.Component.weekday, from: date) - 1]
        
        return weekStr
    }
}
