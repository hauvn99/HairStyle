//
//  ViewUtil.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/15.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class ViewUtil {
    private static var blackBackground: UIView!
    static func length(_4inch: CGFloat, _47inch: CGFloat, _55inch: CGFloat, _58inch: CGFloat) -> CGFloat {
        return DeviceUtil.is4_7inch ? _47inch
            :  DeviceUtil.is5_5inch ? _55inch
            :  DeviceUtil.is5_8inch ? _58inch
            :                         _4inch
    }
    
    static func length(lessThan4inch: CGFloat, etc: CGFloat) -> CGFloat {
        return DeviceUtil.lessThan4inch ? lessThan4inch : etc
    }
    
    static func length(_35inch: CGFloat, _4inch: CGFloat, _47inch: CGFloat, _55inch: CGFloat, _58inch: CGFloat) -> CGFloat {
        return DeviceUtil.is4_7inch ? _47inch
            :  DeviceUtil.is5_5inch ? _55inch
            :  DeviceUtil.is5_8inch ? _58inch
            :  DeviceUtil.is3_5inch ? _35inch
            :                         _4inch
    }
    
    static func imageName(baseName: String) -> String {
        return DeviceUtil.is4_7inch ? baseName + "47"
            :  DeviceUtil.is5_5inch ? baseName + "55"
            :  DeviceUtil.is5_8inch ? baseName + "58"
            :  DeviceUtil.is3_5inch ? baseName + "35"
            :                         baseName + "4"
    }

    
    //viewにぴったり入るフレーム
    static func scaleToFillFrame(view: UIView) -> CGRect {
        return CGRect(x: 0, y: 0, width: view.width, height: view.height)
    }

    //画面全体のフレーム
    static var fullScreenFrame: CGRect {
//        return CGRect(
//            x: frame.origin.x,
//            y: frame.origin.y,
//            width: frame.width * DeviceUtil.basicRatio,
//            height: frame.height * DeviceUtil.basicRatio)
        //return frame * DeviceUtil.basicRatio
        
        return ViewUtil.frameBySize(size: DeviceUtil.screenSize)
        
    }

    //サイズから(0,0)起点のフレームを生成
    static func frameBySize(size: CGSize) -> CGRect {
        return CGRect(x: 0, y: 0, width: size.width, height: size.height)
    }
    
    //Xibをインスタンス化
    static func loadNib<T>(name: String) -> T {
        return UINib(nibName: name, bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! T
    }

    //Storyboard名とStoryboardIDからVCをインスタンス化
    static func loadStoryboardVC<Type>(storyboard: String, identifier: String) -> Type {
        let storyboard = UIStoryboard(name: storyboard, bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: identifier) as! Type
    }
    
    //Storyboard名から最初のVCをインスタンス化
    static func loadStoryboardInitialVC<Type>(storyboard: String) -> Type {
        let storyboard = UIStoryboard(name: storyboard, bundle: nil)
        return storyboard.instantiateInitialViewController() as! Type
    }
    
    //WindowのrootViewControllerを変更
    static func changeRootVC(vc: UIViewController) {
//        AppDelegate.shared.window!.rootViewController = vc
        ViewUtil.normalizeViewHierarchy()
    }
    
    ///Viewの階層を正常化
    static func normalizeViewHierarchy() {
//        AppDelegate.shared.window!.bringSubviewToFront(TextFieldLockViewManager.shared.view)
//        AppDelegate.shared.window!.bringSubviewToFront(DialogManager.shared.view)
//        AppDelegate.shared.window!.bringSubviewToFront(AppNotificationManager.shared.view)
//        AppDelegate.shared.window!.bringSubviewToFront(IndicatorManager.shared.view)
//        AppDelegate.shared.window!.bringSubviewToFront(ToastManager.shared.view)
    }
    
    //現在のVCを取得
    static var currentVC: UIViewController { return SceneDelegate.shared.window!.rootViewController!.topVC }
    
    //現在のBaseVCを取得
    static var currentBaseVC: BaseVC? { return ViewUtil.currentVC as? BaseVC }
    
    //Presentする元のVCを取得(MainTBC直下のVCでPresentする場合は、そのVCではなくMainTBCを戻す)
//    static var currentVCForPresent: UIViewController {
//        let vc = ViewUtil.currentVC
//        return MainTBC.current.isMainTBCVC(vc: vc) ? MainTBC.current : vc
//    }

    //下線追加
    @discardableResult
    static func addUnderLine(view: UIView, color: UIColor, height: CGFloat, leading: CGFloat, trailing: CGFloat) -> UIView {
        let line = UIView()
        line.backgroundColor = color
        line.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(line)
        ConstraintUtil.leading(item: line, toItem: view, constant: leading)
        ConstraintUtil.trailing(item: line, toItem: view, constant: -trailing)
        ConstraintUtil.bottom(item: line, toItem: view, constant: 0)
        ConstraintUtil.height(item: line, constant: height)
        return line
    }
 
    ///WindowLevelを標準に戻してステータスバーを表示
    static func showStatusBarByWindowLevel() {
        SceneDelegate.shared.window!.windowLevel = UIWindow.Level(rawValue: 0)
    }
    
    ///WindowLevelをあげてステータスバーを表示
    static func hideStatusBarByWindowLevel() {
        SceneDelegate.shared.window!.windowLevel = UIWindow.Level(rawValue: 1001)
    }
    
    ///先祖のScrollView取得
    static func parentScrollView(view: UIView) -> UIScrollView? {
        return view.superview == nil ? nil : view.superview is UIScrollView ? (view.superview as! UIScrollView) : self.parentScrollView(view: view.superview!)
    }
    
    ///メッセージ画面をPresent
//    static func presentMessageVC(parentVC: UIViewController, memberId: String, messageKey: String, profPhoto: UserImageUrl, nickname: String, age: Int) {
//        let vc: MessageDetailVC = ViewUtil.loadStoryboardVC(storyboard : "MessageDetail", identifier: "MessageDetailVC")
//        vc.messageListUser = MessageListUser(members_id: memberId, group: .normal, isStatusWithDraw: false, nickname: nickname, age: age, unread: false, msg: "", submsg: "", created_at: "", profile_photo_url: profPhoto, noreply_icon: false, unread_icon: false, sex: 0, kind: 0, photo_check: false, is_new: false, login_status: .online, pref: "", pref_codes_id: "", pr: "", api_members_id: "", message_key: messageKey, prof_photo_id: false, pref_name_all: "", aocca_start: 0, aocca_end: 0, template_nkind: .noTemplate, templates_id: 0, msgowner:1, isSystemTemplate: false)
//        let navi: MessageNavi = ViewUtil.loadStoryboardInitialVC(storyboard: "Message")
//        navi.viewControllers = [vc]
//        parentVC.presentVC(vc: navi, animated: true)
//    }
    
    // add black view
    static func addBlackViewLayer(viewVC: UIViewController) {
        blackBackground = UIView(frame: viewVC.view.frame)
        blackBackground.backgroundColor = Color.black
        blackBackground.alpha = 0.75
        viewVC.view.addSubview(blackBackground)
    }
    
    static func removeBlackViewLayer() {
        if blackBackground != nil {
            blackBackground.removeFromSuperview()
        }
    }
    
    static func getBaseView() -> UIViewController? {
        var baseView = UIApplication.shared.keyWindow?.rootViewController
        while ((baseView?.presentedViewController) != nil)  {
            baseView = baseView?.presentedViewController
        }
        return baseView
    }
    
//    static func pushBaseVC(viewControlStoryboad: String, firstNavi: String, animate: Bool = true) {
//        let storyboard: UIStoryboard = UIStoryboard(name: viewControlStoryboad, bundle: nil)
//        let firstnavi = storyboard.instantiateViewController(withIdentifier: firstNavi) as! UINavigationController
//        ViewUtil.currentVC.present(firstnavi, animated: animate, completion: nil)
//    }
}
