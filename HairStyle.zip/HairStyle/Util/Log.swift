//
//  Log.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/03.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import Foundation

func debugLog(_ obj: Any?,
              function: String = #function,
              line: Int = #line,
              file: String = #file) {
    #if !PRODUCTION
        if let obj = obj {
            print("[File:\(file) Function:\(function) Line:\(line)] : \(obj)")
        } else {
            print("[File:\(file) Function:\(function) Line:\(line)]")
        }
    #endif
}
