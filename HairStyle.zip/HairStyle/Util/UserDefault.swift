//
//  UserDefault.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/03.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class UserDefault {
    static func existsKey(key: String) -> Bool {
        return UserDefaults.standard.object(forKey: key) != nil
    }
    
    static func getValue(key: String, defaultValue: Any? = nil) -> Any? {
        return UserDefault.existsKey(key: key) ? UserDefaults.standard.object(forKey: key) : defaultValue
    }
    
    static func setValue(value: Any, key: String, save: Bool = true) {
        UserDefaults.standard.set(value, forKey: key)
        if save {
            UserDefault.save()
        }
    }
    
    static func remove(key: String, save: Bool = true) {
        UserDefaults.standard.removeObject(forKey: key)
        if save {
            UserDefault.save()
        }
    }
    
    static func save() {
        UserDefaults.standard.synchronize()
    }
    
    static func getString(key: String, defaultValue: String? = nil) -> String? {
        return UserDefault.existsKey(key: key) ? UserDefaults.standard.string(forKey: key) : defaultValue
    }
    
    static func setString(value: String, key: String, save: Bool = true) {
        UserDefault.setValue(value: value, key: key, save: save)
    }
}
