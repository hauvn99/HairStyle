//
//  TypeUtil.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/27.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

typealias Event = () -> Void
typealias Json = [String:Any]

enum SnsType: Int {
    case noSns = 0
    case facebook
    case twitter
    case google
    case yahoo
    
    var name: String { return ["", "Facebook", "Twitter", "Google", "Yahoo!"][self.rawValue] }
    var typeString: String { return ["", "facebook", "twitter", "google", "yahoo"][self.rawValue] }
}
