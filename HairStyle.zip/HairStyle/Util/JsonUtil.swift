//
//  JsonUtil.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/02.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class JsonUtil {
    static func parse(data : Data) -> Json? {
        do {
            if let parsedData = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? Json {
                return parsedData
            } else {
                return nil
            }
        } catch let error as NSError {
            print(error.localizedDescription)
            return nil
        }
    }
    
    static func createData(json: Json) -> Data {
        let jsonData = try! JSONSerialization.data(withJSONObject: json, options: [])
        return jsonData
    }
    
    static func createString(json: Json) -> String {
        let data = JsonUtil.createData(json: json)
        return String(data: data, encoding: String.Encoding.utf8)!
    }
    
    static func createJson(string: String) -> Json? {
        let data = string.data(using: String.Encoding.utf8)
        let json : Json? = JsonUtil.parse(data: data!)
        
        return json
    }
    
    func saveJson(fileName: String, data: Json) {
        do {
            let fileURL = try FileManager.default
                .url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                .appendingPathComponent("\(fileName).json")
            try JSONSerialization.data(withJSONObject: data)
                .write(to: fileURL)
        } catch {
            print(error)
        }
    }
    
    func readJson(fileName: String) {
        do {
            let fileURL = try FileManager.default
                .url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                .appendingPathComponent("\(fileName).json")

            let dataFile = try Data(contentsOf: fileURL)
            let dictionary = try JSONSerialization.jsonObject(with: dataFile)
            print("==============++++++++++++++++")
            print(dictionary)
            print("++++++++++++++++==============")
        } catch {
            print(error)
        }
    }
    
    func saveJSONEncode<T: Codable>(named: String, object: T) {
        do {
            let fileURL = try FileManager.default
                .url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                .appendingPathComponent(named)
            let encoder = try JSONEncoder().encode(object)

            try encoder.write(to: fileURL)
        } catch {
            print("JSONSave error of \(error)")
        }
    }
    
    func readJSONDecode<T: Codable>(named: String, _ object: T.Type) -> T? {
         do {
             let fileURL = try FileManager.default
                    .url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                    .appendingPathComponent(named)
             let data = try Data(contentsOf: fileURL)

             let object = try JSONDecoder().decode(T.self, from: data)

            return object
        } catch {
            return nil
        }
    }
}
//https://www.appcoda.com/json-codable-swift/
