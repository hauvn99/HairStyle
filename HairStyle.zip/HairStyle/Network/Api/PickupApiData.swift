//
//  PickupApiData.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/02.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import Foundation

struct PickupApiData: Codable {
    var response: String
    var showPickupTutorial: Bool
    var isRequirePhoto: Bool
    var members: [PickupMembers]!
    
    private enum CodingKeys: String, CodingKey {
        case response = "success"
        case showPickupTutorial = "show_pickup_tutorial"
        case isRequirePhoto = "isRequirePhoto"
        case members = "member"
    }
    init() {
        self.response = "99"
        self.showPickupTutorial = false
        self.isRequirePhoto = false
        self.members = nil
    }
}

struct PickupDisplayArea: Codable {
    var dataCommunity: [PickupCommunity]?
    var dataText: String //カード下部表示データ(data_type0,3,4の時に使用)
    var dataType: Int! //カード下部表示データタイプ(0:メッセージ付きいいね,1:共通コミュニティ,2:参加コミュニティ,3:自己PR,4:「はじめまして！」)
    var dataCnt: Int! //共通/参加コミュニティ数
    
    private enum CodingKeys: String, CodingKey {
        case dataCommunity = "data_community"
        case dataText = "data_text"
        case dataType = "data_type"
        case dataCnt = "data_cnt"
    }
    init() {
        self.dataCommunity = []
        self.dataText = ""
        self.dataType = 4
        self.dataCnt = 0
    }
}

struct PickupMembers: Codable {
    var apiMembersId: String
    var sex: String
    var nickname: String
    var age: Int
    var prefName: String
    var loginStatus: String
    var isNew: Int
    var status: String
    var profilePhotoUrl: String
    var subPhotosUrl: [String]!
    var photoCnt: Int
//    var aoccaType: Int!
//    var dataText: String
//    var dataType: Int!
//    var dataCnt: Int!
//    var displayArea: [PickupDisplayArea]!
    
    private enum CodingKeys: String, CodingKey {
        case apiMembersId = "api_members_id"
        case sex
        case nickname
        case age
        case prefName = "pref_name"
        case loginStatus = "login_status"
        case isNew = "is_new"
        case status
        case profilePhotoUrl = "profile_photo_url"
        case subPhotosUrl = "sub_photos_url"
        case photoCnt = "photo_cnt"
//        case aoccaType = "aocca_type"
//        case dataText = "data_text"
//        case dataType = "data_type"
//        case dataCnt = "data_cnt"
//        case displayArea = "display_area"
    }
    init() {
        self.apiMembersId = ""
        self.sex = "1"
        self.nickname = ""
        self.age = 18
        self.prefName = ""
        self.loginStatus = "99"
        self.isNew = 0
        self.status = ""
        self.profilePhotoUrl = "silhouette_man.png"
        self.subPhotosUrl = []
        self.photoCnt = 0
//        self.aoccaType = 0
//        self.dataText = ""
//        self.dataType = 4
//        self.dataCnt = 0
//        self.displayArea = []
    }
}

struct PickupCommunity: Codable {
    var id: String
    var communityCategoriesId: String
    var createMembersId: String
    var name: String
    var path: String
    var check: String
    var memberCnt: String
    var favoriteFlg: String     //運営からのおすすめフラグ
    var adminFlg: String        //公式コミュニティフラグ
    var webOnlyFlg: String      //webのみ表示(0:webのみではない,1:webのみ)
    var lastjoinAt: String?      //最終参加日時
    var createdAt: String?       //作成日時
    var updatedAt: String?       //最終参加日時
    var deletedAt: String?      //最終参加日時
    var isJoin: String          //参加状況(0:未参加,1:参加中)
    //var common: Bool          //共通のコミュニティフラグ
    
    private enum CodingKeys: String, CodingKey {
        case id
        case communityCategoriesId = "community_categories_id"
        case createMembersId = "create_members_id"
        case name
        case path
        case check
        case memberCnt = "member_cnt"
        case favoriteFlg = "favorite_flg"
        case adminFlg = "admin_flg"
        case webOnlyFlg = "web_only_flg"
        case lastjoinAt = "lastjoin_at"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
        case deletedAt = "deleted_at"
        case isJoin = "is_join"
        //case common
    }
    init() {
        self.id = ""
        self.communityCategoriesId = ""
        self.createMembersId = ""
        self.name = ""
        self.path = ""
        self.check = ""
        self.memberCnt = ""
        self.favoriteFlg = ""
        self.adminFlg = ""
        self.webOnlyFlg = ""
        self.lastjoinAt = nil
        self.createdAt = nil
        self.updatedAt = nil
        self.deletedAt = nil
        self.isJoin = ""
        //self.common = true
    }
}

