//
//  PhotoApi.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/04.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import Foundation
struct PhotoApiData: Codable {
    var members: [PhotoApi]!
    
    private enum CodingKeys: String, CodingKey {
        case members = "member"
    }
    init() {
        self.members = nil
    }
}
struct PhotoApi: Codable {
    var profilePhotoUrl: String
    var subPhotosUrl: [String]!
    
    private enum CodingKeys: String, CodingKey {
        case profilePhotoUrl = "profile_photo_url"
        case subPhotosUrl = "sub_photos_url"
    }
    init() {
        self.profilePhotoUrl = "silhouette_man.png"
        self.subPhotosUrl = []
    }
}
