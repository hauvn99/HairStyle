//
//  NiceApiData.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/02.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

struct NiceApiData: Codable {
    var response: String
    var ageCheck: Bool
    var nicedCnt: Int
    var showPickupTutorial: Bool
    var showThanksFreeDialog: Bool
    var isRequirePhoto: Bool
    var members: [NiceMembers]!
    private enum CodingKeys: String, CodingKey {
        case response = "success"
        case ageCheck = "age_check"
        case nicedCnt = "niced_cnt"
        case showPickupTutorial = "show_pickup_tutorial"
        case members = "member"
        case isRequirePhoto
        case showThanksFreeDialog = "show_thanks_free_dialog"
    }
    init() {
        self.response = "99"
        self.ageCheck = false
        self.nicedCnt = 0
        self.showPickupTutorial = false
        self.showThanksFreeDialog = false
        self.isRequirePhoto = true
        self.members = nil
    }
}

struct NiceMembers: Codable {
    var apiMemberId: String
    var msgkey: String
    var niceBtn: Int
    var niceItemContent: String!
    var profPhotoUrl: String
    var subPhotosUrl: [String]
    var nickname: String
    var loginStatus: Int
    var isNew: Int
    var age: Int
    var prefName: String
    var photoCnt: Int
    var niceMessage: String
    var displayAreas: [DisplayArea]?
    private enum CodingKeys: String, CodingKey {
        case apiMemberId = "api_members_id"
        case msgkey
        case niceBtn = "nice_btn"
        case niceItemContent = "nice_item_content"
        case profPhotoUrl = "prof_photo_url"
        case subPhotosUrl = "sub_photos_url"
        case nickname
        case loginStatus = "login_status"
        case isNew = "is_new"
        case age
        case prefName = "pref_name"
        case photoCnt = "photo_cnt"
        case niceMessage = "nice_message"
        case displayAreas = "display_area"
    }
    init() {
        self.apiMemberId = ""
        self.msgkey = ""
        self.niceBtn = 0
        self.niceItemContent = ""
        self.profPhotoUrl = ""
        self.subPhotosUrl = []
        self.nickname = ""
        self.loginStatus = 0
        self.isNew = 0
        self.age = 0
        self.prefName = ""
        self.photoCnt = 0
        self.niceMessage = ""
        self.displayAreas = nil
    }
}

struct DisplayArea: Codable {
    var dataCommunity: [NicedCommunity]?
    var dataText: String
    var dataType: Int
    private enum CodingKeys: String, CodingKey {
        case dataCommunity = "data_community"
        case dataText = "data_text"
        case dataType = "data_type"
    }
    init() {
        self.dataCommunity = nil
        self.dataText = ""
        self.dataType = 0
    }
}

struct NicedCommunity: Codable {
    var name: String
    var webOnlyFlg: Int
    private enum CodingKeys: String, CodingKey {
        case name
        case webOnlyFlg = "web_only_flg"
    }
    init() {
        self.name = ""
        self.webOnlyFlg = 0
    }
}
