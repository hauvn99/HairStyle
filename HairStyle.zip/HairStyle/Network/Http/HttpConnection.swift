//
//  HttpConnection.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/03.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

protocol HttpConnectionDelegate: class {
    func onSuccess(httpConnection: HttpConnection, responseData: Data)
    func onError(httpConnection: HttpConnection)
}

class HttpConnection : NSObject, URLSessionDataDelegate {
    private var urlString: String!
    weak var httpConnectionDelegate: HttpConnectionDelegate?
    private var json: Json!
    private var timeoutInterval: TimeInterval!
    private var task: URLSessionDataTask?
    private var responseData: Data!
    private(set) var isRunning = false
    private(set) var isSuccess = false
    private(set) var isCancel = false
    private(set) var isGet = false
    
    init(urlString: String, json: Json = Json(), timeoutInterval: TimeInterval, isGet: Bool = false) {
        super.init()
        self.urlString = urlString
        self.json = json
        self.timeoutInterval = timeoutInterval
        self.isGet = isGet
        print("URL=\(String(describing: self.urlString))")
        print("リクエスト=\(String(describing: self.json))")
    }
    
    //接続
    func connect() {
        self.responseData = Data()
        let conf = URLSessionConfiguration.default
        conf.timeoutIntervalForResource = self.timeoutInterval
        let session = URLSession(configuration: conf, delegate: self, delegateQueue: OperationQueue.main)
        
        var url = URLRequest(url: URL(string: self.urlString)!)
        url.httpMethod = (self.isGet == false) ? "POST" : "GET"
        if self.json.isEmpty == false || self.isGet == false {
            self.setData(url: &url)
        }
        
        self.task = session.dataTask(with: url)
        self.isRunning = true
        self.isSuccess = false
        self.isCancel = false
        self.task!.resume()
    }
    
    //データの設定
    func setData(url: inout URLRequest) {
        let jsonData = try! JSONSerialization.data(withJSONObject: self.json, options: [])
        let data:String = String(data: jsonData, encoding: .utf8)!
        url.httpBody = data.data(using: String.Encoding(rawValue: String.Encoding.utf8.rawValue))
        url.addValue("application/json", forHTTPHeaderField: "Content-Type")
    }
    
    //終了
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        self.isRunning = false
        session.invalidateAndCancel()
        if error == nil {
            self.isSuccess = true
            self.httpConnectionDelegate?.onSuccess(httpConnection: self, responseData: self.responseData!)
        } else if self.isCancel {
        } else{
            print(error.debugDescription)
            self.httpConnectionDelegate?.onError(httpConnection: self)
        }
    }
    
    //キャンセル
    func cancel() {
        self.isCancel = true
        self.task?.cancel()
        self.task = nil
    }
    
    //レスポンス
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Swift.Void) {
        if (response as! HTTPURLResponse).statusCode == 200 {
            completionHandler(.allow)
        }else{
            session.invalidateAndCancel()
            completionHandler(.cancel)
        }
    }
    
    //データ取得
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        self.responseData!.append(data)
    }
}
