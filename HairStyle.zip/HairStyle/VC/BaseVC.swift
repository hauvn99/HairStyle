//
//  BaseVC.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/02/25.
//

import UIKit

class BaseVC: UIViewController, UIGestureRecognizerDelegate {
    private(set) var hasViewDidAppear = false
    private(set) var hasViewWillAppear = false
    private(set) var hasPop = false
    private var baseNavi: BaseNavi? { return self.navigationController as? BaseNavi }
    var isEnableBack: Bool { return true } //バックボタンの有無とスワイプバックの有効
    var existsNaviBar: Bool { return true }
    var existsTabBar: Bool { return false }
    var existsNaviUnderLine: Bool { return true }
    var hasNavi: Bool { return self.navigationController != nil }
    var parentVCOfModal: BaseVC? { return (self.presentingViewController is UINavigationController ? (self.presentingViewController as! UINavigationController).topViewController : self.presentingViewController) as? BaseVC }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        self.commonInit()
    }
    
    deinit { print("deinit \(String(describing: type(of: self)))") }
    
    func commonInit() {
        self.navigationItem.hidesBackButton = true
        
        if let title = self.navigationItem.title {
            self.navigationItem.title = ls(title)
        }
        self.hidesBottomBarWhenPushed = !self.existsTabBar
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.tintColor = UIColor.clear
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !self.hasViewWillAppear {
            self.createBackButton()
        }
        self.baseNavi?.changeNavi(isShow: self.existsNaviUnderLine)
        self.navigationController?.setNavigationBarHidden(!self.existsNaviBar, animated: animated)
        self.hasViewWillAppear = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.enableSwipeBack()
        self.hasViewDidAppear = true
    }
    
    ///スワイプバック有効化
    func enableSwipeBack() {
        guard let navigationController = self.navigationController else { return }
        let isEnabled = self.isEnableBack && navigationController.viewControllers.first !== self
        navigationController.interactivePopGestureRecognizer?.isEnabled = isEnabled
        navigationController.interactivePopGestureRecognizer?.delegate = isEnabled ? self : nil
        navigationController.interactivePopGestureRecognizer?.addTarget(self, action: #selector(BaseVC.swipeBack))
    }
    
    ///バックボタン作成
    func createBackButton() {
        if (self.navigationController?.viewControllers.count ?? 0) <= 1 || self.navigationController?.topViewController !== self { return }
        if !self.isEnableBack { return }
        
        let barButtonItem = UIBarButtonItem(image: UIImage(named: "header_btn_back")!.withRenderingMode(.alwaysOriginal) , style: .plain, target: self, action: #selector(BaseVC.pushedBackButton))
        self.navigationItem.addLeftBarButtonItem(item: barButtonItem, isLastPosition: false)
    }
    
    ///バックボタン押下時
    @objc func pushedBackButton() {
        if self.hasPop { return }
        if self.backEvent() {
            self.popVC()
        }
    }
    
    ///バックボタン押下時のイベント、popしたくない場合は処理とreturn false
    func backEvent() -> Bool { return true }
    
    ///スワイプバックイベント
    @objc func swipeBack() {}
    
    ///StandardNavi作成
    func createStandardNavi() -> StandardNavi {
        let navi = StandardNavi.create()
        navi.pushViewController(self, animated: false)
        return navi
    }
    
    ///Push
    func pushVC(vc: BaseVC,animate: Bool = true) {
        self.navigationController?.pushViewController(vc, animated: animate)
    }
    
    ///Pop
    func popVC() {
        self.navigationController?.popViewController(animated: true)
        self.hasPop = true
    }
    
    override func dismiss(animated flag: Bool, completion: (() -> Void)? = nil) {
        if self.isModal {
            self.parentVCOfModal?.viewWillAppearByDismiss()
        }
        super.dismiss(animated: flag, completion: completion)
    }
    
    override func present(_ viewControllerToPresent: UIViewController, animated flag: Bool, completion: (() -> Void)? = nil) {
        self.viewWillDisappearByPresent(vc: viewControllerToPresent)
        super.present(viewControllerToPresent, animated: flag, completion: completion)
    }
    
    func viewWillDisappearByPresent(vc: UIViewController) {
        self.enableScrollToTop(view: self.view, enable: false)
    }
    
    func viewWillAppearByDismiss() {
        self.enableScrollToTop(view: self.view, enable: true)
    }
    
    ///透明なVCをPresentするとステータスバーを押下できてしまうため、SubViewのUIScrollViewのscrollsToTopを許可/禁止する
    func enableScrollToTop(enable: Bool) {
        self.enableScrollToTop(view: self.view, enable: enable)
    }
    
    private func enableScrollToTop(view: UIView, enable: Bool) {
        for subview in view.subviews {
            if let scrollView = subview as? UIScrollView {
                scrollView.scrollsToTop = enable
                return
            }
        }
        for subview in view.subviews {
            self.enableScrollToTop(view: subview, enable: enable)
        }
    }
}

