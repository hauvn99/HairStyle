//
//  Birthday.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/29.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

struct Birthday {
    private(set) var date: Date
    var age: Int { return DateUtil.age(birthday: self.date) }
    var text: String { return ls("edit_prof_save_birth_date_text", args: self.date.year, self.date.month, self.date.day) }
    var apiValue: String { return String(format: "%04d-%02d-%02d", self.date.year, self.date.month, self.date.day) }
    
    init?(date: Date? = Date()) {
        if date == nil {
            return nil
        } else {
            self.date = date!
        }
    }

    init?(apiValue: String) {
        let date = Date(string: apiValue, format: "yyyy-MM-dd")
        if date == nil {
            return nil
        } else {
            self.date = date!
        }
    }
}
