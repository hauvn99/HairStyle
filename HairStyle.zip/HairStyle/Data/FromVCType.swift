//
//  FromVCType.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/08/27.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

enum FromVCType: Int {
    //TODO searchは削除予定
    case search = 1
    case footprint = 3
    case favorite = 4
    case memo = 6
    case keep = 12
    case kept = 13
    case coupling = 14
    case limited = 15
    case community = 16
    case tweet_all = 17
    case tweet_favorite = 18
    case main_search = 19
    case simple_search = 20
    case aocca_search = 21
    case message_detail = 26
    case LIST_TYPE_PICKUP = 32
}

//3:あしあとリスト
//4:お気に入りリスト
//6:メモリスト
//12:気になるした
//13:気になるされた
//14:両想い
//15:見ちゃいや
//16:コミュニティ詳細
//17:つぶやき（すべて）
//18:つぶやき（お気に入り）
//19:メイン検索（プロフ検索）
//20:かんたん検索
//21:aocca検索
//26:メッセージ詳細
