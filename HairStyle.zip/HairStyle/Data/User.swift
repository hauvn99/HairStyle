//
//  User.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/09.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

//import UIKit

enum Gender: String {
    case male = "male"
    case female = "female"
    case none = "none"
    
    init(data: String) {
        self = Gender.init(rawValue: data) ?? Gender.none
    }
}

