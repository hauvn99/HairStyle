//
//  UserImageUrl.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/03.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

struct UserImageUrl {
    var url: String
    var isMale: Bool?
    var isWithdraw: Bool
    var isSilhouette: Bool { return self.url.hasPrefix("silhouette") || self.url.hasPrefix("/assets/img/silhouette_") }
    var isSet: Bool { return !self.isSilhouette }

    init(url: String, isMale: Bool? = nil, isWithdraw: Bool = false) {
        self.url = url
        self.isMale = isMale
        self.isWithdraw = isWithdraw
        if self.isMale == nil && self.isSilhouette {
            self.isMale = self.url.contains("silhouette_m")
        }
    }
    
    init(isMale: Bool) {
        self.url = "silhouette"
        self.isMale = isMale
        self.isWithdraw = false
    }
}
