//
//  StructData.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/07/06.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit
struct loginUserInfo {
    var nickname:String
    var gender:Gender
}
struct PhotoData {
    var name: String
}
struct PhotoCell {
    var title: String
    var image: UIImage
    var url: String
}
