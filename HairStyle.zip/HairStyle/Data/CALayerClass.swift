//
//  CALayerClass.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/09/10.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

struct CALayerClass {
    let title: String
    let description: String
}
