//
//  HairData.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/06/02.
//

import UIKit

struct HairData {
    var colors: [UIColor] = []
    var hairWomen: [HairItemData] = []
    var hairMen: [HairItemData] = []
    
    init() {
        self.colors = [UIColor.init(red: 238/255, green: 196/255, blue: 187/255, alpha: 1),
                       UIColor.init(red: 245/255, green: 175/255, blue: 27/255, alpha: 1),
                       UIColor.init(red: 188/255, green: 133/255, blue: 95/255, alpha: 1),
                       UIColor.init(red: 89/255, green: 192/255, blue: 237/255, alpha: 1)]
        for i in 0..<4 {
            self.hairWomen.append(HairItemData(photoUrl: "hair\(i+1)"))
            self.hairMen.append(HairItemData(photoUrl: "men_hair\(i+1)"))
        }
    }
}

struct HairItemData {
    var name: String = ""
    var photoUrl: String
}
