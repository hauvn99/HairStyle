//
//  AppConst.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/03.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class AppConst {
    #if DEVELOP
    static let webHost   = "cnt15.devenb.com"
    static let apiKey    = "BRIJBSPFMS"
    static let shareKey  = "83d46d11bef54494bb08a3d77600469c"
    static let cdn_dom   = "https://cdn.devenb.com/"
    static let domainDefault = "https://api15.devenb.com/"
    #elseif STAGING
    static let webHost   = "buronto.com"
    static let apiKey    = "OIBNWONBEE"
    static let shareKey  = "9f7f1fd5d76f4d40bed07367503ac0d6"
    static let cdn_dom   = "https://cdn.buronto.com/"
    static let domainDefault = "https://api.buronto.com/"
    #elseif CLIENT
    static let webHost   = "soramiso.com"
    static let apiKey    = "OIBNWONBEE"
    static let shareKey  = "83d46d11bef54494bb08a3d77600469c"
    static let cdn_dom   = "https://cdn.soramiso.com/"
    static let domainDefault = "https://api.soramiso.com/"
    #else
    static let webHost   = "aocca.jp"
    static let apiKey    = "OIBNWONBEE"
    static let shareKey  = "ebfe31db2fff4231a9a1186ba06c2424"
    static let cdn_dom   = "https://cdn.aocca.jp/"
    static let domainDefault = "https://api.aocca.jp/"
    #endif
    
    static var domain : String { return getDomain()}
    //Zipバージョン
    static let zipVersion = "v1.0.1.17"
    static let apiTimeoutInterval : TimeInterval = 20
    static let contactAddress = "info@aocca.jp"
    static let supportAddress = "support@aocca.jp"

    // define
    static let SearchSort = "SEARCHSORT"
    static let AoccaSearchSort = "AoccaSearch"
    static let CommunityDetailSearch = "CommunityDetailSearch"
    static let isProfPhotoSetAtFacebookLogin = "isProfPhotoSetAtFacebookLogin" //会員登録(Facebookログイン)時に、FB側でプロフ写真を登録していたかどうか
    static let KeyExaminationMode = "ExaminationMode"
    static let KeySwitchingDomain = "SwitchingDomain"
    static let ReproSDKVersion = "v4.8.0"
    static let MemStatusNormal       = "0" // 従量課金
    static let MemStatusFlatRatePack = "1" // 定額パック課金
    static let ReproControlGroupFlag = "ReproControlGroupFlag"
    static let ConfirmHasNoNiceDialogKey = "ConfirmHasNoNiceDialogKey"
    static let AoccaStartMonth = 3
    static let AoccaStartAge = 18
    //nice - items - id
    static let NICE_ITEMS_MALE_NORMAL_NICE = 1 // 男性のノーマルのいいね！
    static let NICE_ITEMS_FEMALE_NORMAL_NICE = 7 // 女性のノーマルのいいね！

    //static let MemStatusHogePack     = "2" // hogeパック課金
    //static let MemStatusFugaPack     = "4" // fugaパック課金
    //static let MemStatusPiyoPack     = "8" // piyoパック課金

    static let ProductTypePoint        = AppConst.MemStatusNormal
    static let ProductTypeFlatRatePack = AppConst.MemStatusFlatRatePack
    
    static func getDomain() -> String {
        let checkValue = UserDefault.getValue(key: KeyExaminationMode, defaultValue: false) as! Bool
        let switchingDomain = UserDefault.getString(key: KeySwitchingDomain, defaultValue: domainDefault)!
        return checkValue ? switchingDomain : domainDefault
    }
}
