//
//  Color.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/15.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class Color {
    ///RGBとalphaからUIColor作成
    private static func rgba(red: UInt, green: UInt, blue: UInt, alpha: CGFloat) -> UIColor {
        return UIColor(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: alpha)
    }
    
    ///RGBからUIColor作成
    private static func rgb(red: UInt, green: UInt, blue: UInt) -> UIColor{
        return Color.rgba(red:red, green:green, blue:blue, alpha:1)
    }
    
    ///16進数表記とalphaからUIColor作成
    private static func rgba16(hex: UInt, alpha: CGFloat) -> UIColor {
        return Color.rgba(red: (hex & 0xFF0000) >> 16, green: (hex & 0x00FF00) >> 8, blue: hex & 0x0000FF, alpha: alpha)
    }
    
    ///16進数表記からUIColor作成
    private static func rgb16(hex: UInt) -> UIColor {
        return Color.rgba16(hex: hex, alpha: 1)
    }

    public enum Name: String {
        case black0
        case black50
        case black70
        case darkGrayishPurple10
        case white
        case black
        case paleGray
        case lightGray
        case gray
        case darkGray
        case palePurple
        case lightPurple
        case purple
        case brightPurple
        case deepPurple
        case paleGrayishPurple
        case lightGrayishPurple
        case darkGrayishPurple
        case palePink
        case rosePink
        case pink
        case vividPink
        case darkHotPink
        case cherryPink
        case lightOrange
        case deepOrange
        case emeraldGreen
        case paleBlue
        case lightBlue
        case deepYellow
        case lightGrayishBlue
        case lightYellow
        case lightPink
        case softPurple
        case softGrayishPurple
        case paleLightPurple
        case deepGray
        case deepGrayProfileBtnFavorite
        case paleYellow
        case softGray
        case softYellow
        case yellow
        case grayishPurple
        case darkPink
        case paleOrange
        case paleAquaBlue
        case paleBlueGreen
        case red
        case systemGray5
    }

    static public func from(name: Name) -> UIColor {
        switch name {
        case .black0: return Color.black0
        case .black50: return Color.black50
        case .black70: return Color.black70
        case .darkGrayishPurple10: return Color.darkGrayishPurple10
        case .white: return Color.white
        case .black: return Color.black
        case .paleGray: return Color.paleGray
        case .lightGray: return Color.lightGray
        case .gray: return Color.gray
        case .darkGray: return Color.darkGray
        case .palePurple: return Color.palePurple
        case .lightPurple: return Color.lightPurple
        case .purple: return Color.purple
        case .brightPurple: return Color.brightPurple
        case .deepPurple: return Color.deepPurple
        case .paleGrayishPurple: return Color.paleGrayishPurple
        case .lightGrayishPurple: return Color.lightGrayishPurple
        case .darkGrayishPurple: return Color.darkGrayishPurple
        case .palePink: return Color.palePink
        case .rosePink: return Color.rosePink
        case .pink: return Color.pink
        case .vividPink: return Color.vividPink
        case .darkHotPink: return Color.darkHotPink
        case .cherryPink: return Color.cherryPink
        case .lightOrange: return Color.lightOrange
        case .deepOrange: return Color.deepOrange
        case .emeraldGreen: return Color.emeraldGreen
        case .paleBlue: return Color.paleBlue
        case .lightBlue: return Color.lightBlue
        case .deepYellow: return Color.deepYellow
        case .lightGrayishBlue: return Color.lightGrayishBlue
        case .lightYellow: return Color.lightYellow
        case .lightPink: return Color.lightPink
        case .softPurple: return Color.softPurple
        case .softGrayishPurple: return Color.softGrayishPurple
        case .paleLightPurple: return Color.paleLightPurple
        case .deepGray: return Color.deepGray
        case .deepGrayProfileBtnFavorite: return Color.deepGrayProfileBtnFavorite
        case .paleYellow: return Color.paleYellow
        case .softGray: return Color.softGray
        case .softYellow: return Color.softYellow
        case .yellow: return Color.yellow
        case .grayishPurple: return Color.grayishPurple
        case .darkPink: return Color.darkPink
        case .paleOrange: return Color.paleOrange
        case .paleAquaBlue: return Color.paleAquaBlue
        case .paleBlueGreen: return Color.paleBlueGreen
        case .red: return Color.red
        case .systemGray5: return Color.rgb(red: 229,green: 229,blue: 234)
        }
    }

    //プログラマー定義
    static var black0: UIColor { return Color.rgba16(hex: 0x000000, alpha: 0) }
    static var black50: UIColor { return Color.rgba16(hex: 0x000000, alpha: 0.5) }
    static var black70: UIColor { return Color.rgba16(hex: 0x000000, alpha: 0.7) }
    //ナビゲーションバー上は透過できないため、白とdarkGrayishPurple10%の合成色を用意
    static var darkGrayishPurple10: UIColor { return Color.rgb16(hex: 0xececee) }
    //デザイナーさんが定義
    static var white: UIColor { return Color.rgb16(hex: 0xffffff) }
    static var black: UIColor { return Color.rgb16(hex: 0x000000) }
    static var paleGray: UIColor { return Color.rgb16(hex: 0xfafafa) }
    static var lightGray: UIColor { return Color.rgb16(hex: 0xe7e7e9) }
    static var gray: UIColor { return Color.rgb16(hex: 0xd0cfd3) }
    static var darkGray: UIColor { return Color.rgb16(hex: 0xa19fa7) }
    static var palePurple: UIColor { return Color.rgb16(hex: 0xf0eefc) }
    static var lightPurple: UIColor { return Color.rgb16(hex: 0xdab1da) }
    static var purple: UIColor { return Color.rgb16(hex: 0xa080d0) }
    static var brightPurple: UIColor { return Color.rgb16(hex: 0x9168ce) }
    static var deepPurple: UIColor { return Color.rgb16(hex: 0x4c4166) }
    static var paleGrayishPurple: UIColor { return Color.rgb16(hex: 0xdfe2f4) }
    static var lightGrayishPurple: UIColor { return Color.rgb16(hex: 0xd1cee7) }
    static var darkGrayishPurple: UIColor { return Color.rgb16(hex: 0x443f4f) }
    static var palePink: UIColor { return Color.rgb16(hex: 0xfef0f7) }
    static var rosePink: UIColor { return Color.rgb16(hex: 0xff94ab) }
    static var pink: UIColor { return Color.rgb16(hex: 0xfe6a9f) }
    static var vividPink: UIColor { return Color.rgb16(hex: 0xf91767) }
    static var darkHotPink: UIColor { return Color.rgb16(hex: 0xe30050) }
    static var cherryPink: UIColor { return Color.rgb16(hex: 0xf76a88) }
    static var lightOrange: UIColor { return Color.rgb16(hex: 0xffb16a) }
    static var deepOrange: UIColor { return Color.rgb16(hex: 0xd88f48) }
    static var emeraldGreen: UIColor { return Color.rgb16(hex: 0x57cbae) }
    static var paleBlue: UIColor { return Color.rgb16(hex: 0xf3f4f9) }
    static var lightBlue: UIColor { return Color.rgb16(hex: 0x9cc0f1) }
    static var deepYellow: UIColor { return Color.rgb16(hex: 0xe6ab0c) }
    static var lightGrayishBlue: UIColor { return Color.rgb16(hex: 0xabb2bd) }
    static var lightYellow: UIColor { return Color.rgb16(hex: 0xfaefb9) }
    static var lightPink: UIColor { return Color.rgb16(hex: 0xffc9d5) }
    static var softPurple: UIColor { return Color.rgb16(hex: 0xcf92fe) }
    static var softGrayishPurple: UIColor { return Color.rgb16(hex: 0xda9ed6) }
    static var paleLightPurple: UIColor { return Color.rgb16(hex: 0xf6e5ff) }
    static var deepGray: UIColor { return Color.rgb16(hex: 0x727683) }
    static var deepGrayProfileBtnFavorite: UIColor { return Color.rgb16(hex: 0x000015) }
    static var paleYellow: UIColor { return Color.rgb16(hex: 0xfffef2) }
    static var softGray: UIColor { return Color.rgb16(hex: 0xececed) }
    static var softYellow: UIColor { return Color.rgb16(hex: 0xfff9d4) }
    static var yellow: UIColor { return Color.rgb16(hex: 0xfad215) }
    static var grayishPurple: UIColor { return Color.rgb16(hex: 0x887698) }
    static var darkPink: UIColor { return Color.rgb16(hex: 0xe66090) }
    static var paleOrange: UIColor { return Color.rgb16(hex: 0xffe9d4) }
    static var paleAquaBlue: UIColor { return Color.rgb16(hex: 0xcff7f9) }
    static var paleBlueGreen: UIColor { return Color.rgb16(hex: 0x74b6c4) }
    static var red: UIColor { return Color.rgb16(hex: 0xe30050) }
    static var veryLightOrange: UIColor { return Color.rgb16(hex: 0xff9a72) }
}

// aocca_color(zeplin 2/19)
// https://app.zeplin.io/project/5beb999931559f3ff01fd1b0/screen/5c495e11bfb873bf2b0f57a2
// https://convertingcolors.com/rgb-color-209_206_231.html

//white              255,255,255 0xffffff
//black                0,  0,  0 0x000000
//paleGray           250,250,250 0xfafafa
//lightGray          231,231,233 0xe7e7e9
//gray               208,207,211 0xd0cfd3
//darkGray           161,159,167 0xa19fa7
//palePurple         240,238,252 0xf0eefc
//lightPurple        218,177,218 0xdab1da
//purple             160,128,208 0xa080d0
//deepPurple          76, 65,102 0x4c4166
//paleGrayishPurple  223,226,244 0xdfe2f4
//lightGrayishPurple 209,206,231 0xd1cee7
//darkGrayishPurple   68, 63, 79 0x443f4f
//palePink           254,240,247 0xfef0f7
//rosePink           255,148,171 0xff94ab
//pink               254,106,159 0xfe6a9f
//vividPink          249, 23,103 0xf91767
//darkHotPink        227, 0, 80 0xe30050
//cherryPink         247,106,136 0xf76a88
//lightOrange        255,177,106 0xffb16a
//deepOrange         216,143, 72 0xd88f48
//emeraldGreen        87,203,174 0x57cbae
//paleBlue           243,244,249 0xf3f4f9
//lightBlue          156,192,241 0x9cc0f1
//deepYello          230,171, 12 0xe6ab0c
//lightGrayishBlue   171,178,189 0xabb2bd
//lightYello         250,239,185 0xfaefb9
//lightPink          255,201,213 0xffc9d5
//softPurple         207,146,254 0xcf92fe
//softGrayishPurple  218,158,214 0xda9ed6
//PaleLightPurple    246,229,255 0xf6e5ff
//deepGray           114,118,131 0x727683
//deepGrayProfileBtnFavorite 0 0 8 0x000015
//paleYello          255,254,242 0xfffef2
//softGray           236,236,237 0xececed
//softYellow         255,249,212 0xfff9d4
//yellow             250,210, 21 0xfad215
//grayishPurple      136,118,152 0x887698
//darkPink           230, 96,144 0xe66090
//paleOrange         255,233,212 0xffe9d4
//red                227, 0, 80  #e30050
//veryLightOrange    255, 154, 114 #ff9a72
