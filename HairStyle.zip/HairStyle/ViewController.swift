//
//  ViewController.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/02/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
