//
//  TextFieldLockViewManager.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/12.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

protocol TextFieldLockViewManagerDelegate: class {
    func onTouchView(sender: Any)
}

///キーボード表示時にキーボード以外をロックする
class TextFieldLockViewManager {
    ///画面をロックするview
    class TextFieldLockView: UIView {
        private var enableTouchView: UIView?
        
        ///タッチ可能TextFieldの設定
        func setEnableTouchView(view: UIView?) {
            self.enableTouchView = view
        }
        
        ///対象のTextField以外の押下を禁止
        override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
            guard let enableTouchView = self.enableTouchView else { return nil }
            return enableTouchView.hitTest(enableTouchView.convert(point, from: self), with: event) ??  super.hitTest(point, with: event)
        }
    }
    
    static let shared = TextFieldLockViewManager()
    private init() {
        self.genture = UITapGestureRecognizer(target: self, action: #selector(self.touchEvent))
    }
    
    private(set) var view: TextFieldLockView!
    weak var delegate: TextFieldLockViewManagerDelegate?
    private var genture: UITapGestureRecognizer!

    ///起動時にメインのWindowに固定のViewを貼り付ける
    func createView(view: UIView) {
        self.view = TextFieldLockView(frame: ViewUtil.fullScreenFrame)
        self.view.isUserInteractionEnabled = false
        view.addSubview(self.view)
    }
    
    ///キーボードが表示された時、対象のTextField以外の押下を禁止する
    func showKeyboard(enableTouchView: UIView) {
        self.view.isUserInteractionEnabled = true
        self.view.setEnableTouchView(view: enableTouchView)
        self.view.addGestureRecognizer(self.genture)
    }

    ///キーボードが非表示になった時
    func hideKeyboard() {
        self.view.isUserInteractionEnabled = false
        self.view.setEnableTouchView(view: nil)
        self.view.removeGestureRecognizer(self.genture)
    }
    @objc func touchEvent(sender : UITapGestureRecognizer) {
        self.delegate?.onTouchView(sender: self)
    }
}

///画面をロックするview
class TextFieldLockView: UIView {
    private var enableTouchView: UIView?

    ///タッチ可能TextFieldの設定
    func setEnableTouchView(view: UIView?) {
        self.enableTouchView = view
    }
    
    ///対象のTextField以外の押下を禁止
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        guard let enableTouchView = self.enableTouchView else { return nil }
        return enableTouchView.hitTest(enableTouchView.convert(point, from: self), with: event) ??  super.hitTest(point, with: event)
    }
}
