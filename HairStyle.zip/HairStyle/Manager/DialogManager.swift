//
//  DialogManager.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/09.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

///ダイアログの表示を管理、現状１つのダイアログのみ表示
class DialogManager {
    static let shared = DialogManager()
    private init() {}

    static let duplicateDisableTag = -1
    private(set) var view: UIView!
    private var dialogBaseView = Set<DialogBaseView>()
    
    ///起動時にメインのWindowに固定のViewを貼り付ける
    func createView(view: UIView) {
        self.view = UIView(frame: ViewUtil.fullScreenFrame)
        self.view.isUserInteractionEnabled = false
        view.addSubview(self.view)
    }
    
    ///リセット
    func reset() {
        self.dialogBaseView.forEach { self.dismiss(dialogBaseView: $0) }
    }

    ///ダイアログ表示
    func show(dialogBaseView: DialogBaseView) {
        //重複禁止ダイアログのチェック(主にネットワークエラーダイアログ)
        if dialogBaseView.dialog.tag == DialogManager.duplicateDisableTag && (self.dialogBaseView.first { $0.dialog.tag == DialogManager.duplicateDisableTag } != nil) { return }
        ViewUtil.normalizeViewHierarchy()
        self.view.isUserInteractionEnabled = true
        self.dialogBaseView.insert(dialogBaseView)
        self.view.addXibView(view: dialogBaseView)
        dialogBaseView.expand()
//        ViewUtil.currentBaseVC?.enableScrollToTop(enable: false)
    }
    
    ///ダイアログ非表示
    func dismiss(dialogBaseView: DialogBaseView) {
        self.dialogBaseView.remove(dialogBaseView)
        if self.dialogBaseView.count == 0 {
            self.view.isUserInteractionEnabled = false
//            ViewUtil.currentBaseVC?.enableScrollToTop(enable: true)
        }
        dialogBaseView.removeFromSuperview()
    }
}
