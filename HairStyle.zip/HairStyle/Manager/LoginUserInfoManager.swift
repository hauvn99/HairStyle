//
//  LoginUserInfoManager.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/03.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

///会員登録、ログイン処理
class LoginUserInfoManager {
    static let shared = LoginUserInfoManager()
    private var silhoette:String?
    private var partnerSilhoette:String?

    init() {
        self.setValue()
    }
    
    func set(nickname: String, sex: String) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.gLoginUseeInfo.gender = Gender(data: sex)
        self.setValue()
    }
    private func setValue() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        if appDelegate.gLoginUseeInfo.gender == Gender.male {
            self.partnerSilhoette = "silhouette_woman"
            self.silhoette = "silhouette_man"
        } else {
            self.partnerSilhoette = "silhouette_man"
            self.silhoette = "silhouette_woman"
        }
    }
    
    func getSilhoette() -> String {
        return self.silhoette!
    }
    func getPartnerSilhoette() -> String {
        return self.partnerSilhoette!
    }
}
