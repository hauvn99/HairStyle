//
//  IndicatorManager.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/12.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

///インジケータを管理
class IndicatorManager {
    static let shared = IndicatorManager()
    private init() {}
    
    private(set) var view: UIView!
    private var standardIndicatorView: IndicatorView!
    private var lockOnlyIndicatorView: IndicatorView!
    
    ///起動時にメインのWindowに固定のViewを貼り付ける
    func createView(view: UIView) {
        self.view = UIView(frame: ViewUtil.fullScreenFrame)
        self.view.isUserInteractionEnabled = false
        view.addSubview(self.view)
    }
    ///画面全体を覆うインジケータを表示
    func showStandard() {
        self.standardIndicatorView = IndicatorView.createStandard()
        self.standardIndicatorView.show()
    }
    
    ///画面全体を覆うインジケータを非表示
    func removeStandard() {
        self.standardIndicatorView?.remove()
        self.resetIndicator()
    }
    
    ///画面全体を覆う画像なしロックだけのインジケータを表示
    func showLockOnly() {
        ViewUtil.normalizeViewHierarchy()
        self.lockOnlyIndicatorView = IndicatorView.create(isLock: true, parentView: self.view, existsImage: false)
        self.lockOnlyIndicatorView.show()
    }
    
    ///画面全体を覆う画像なしロックだけのインジケータを非表示
    func removeLockOnly() {
        self.lockOnlyIndicatorView?.remove()
    }
    
    func resetIndicator() {
        self.view.removeSubView()
        self.view.isUserInteractionEnabled = false
    }
}
