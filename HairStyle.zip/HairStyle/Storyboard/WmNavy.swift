//
//  WmNavy.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/02/25.
//

import UIKit
class WmNavy: BaseVC {
    override var existsTabBar: Bool { return true }
    
    ///生成
    static func create() -> WmNavy {
        let vc: WmNavy = ViewUtil.loadStoryboardVC(storyboard: "WmNavy", identifier: "WmNavy")
        vc.initialize()
        return vc
    }
    
    ///初期化
    func initialize() {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.renderView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    @IBAction func onClose(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    func renderView() {
        print("WMNavy")
    }
}
