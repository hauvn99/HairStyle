//
//  WmHome.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/02/25.
//

import UIKit
class WmHome: BaseVC, CircleViewDelegate, HairViewDelegate {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var colorStackView: UIStackView!
    @IBOutlet weak var hairStackView: UIStackView!
    
    override var existsTabBar: Bool { return true }
    let data: HairData = HairData.init()
    private var index: Int = 0
    
    ///生成
    static func create() -> WmHome {
        let vc: WmHome = ViewUtil.loadStoryboardVC(storyboard: "WmHome", identifier: "WmHome")
        vc.initialize()
        return vc
    }
    
    ///初期化
    func initialize() {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.renderView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    @IBAction func onClose(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    func renderView() {
        print("WmHome")
        self.imgView.image = UIImage(named: self.data.hairWomen[self.index].photoUrl)
        
        //colorView
        self.colorStackView.removeSubView()
        for i in 0..<self.data.colors.count {
            let itemView = CircleView.create(delegate: self, index: i, width: 20.0, backgroundColor: data.colors[i])
            self.colorStackView.addArrangedSubview(itemView)
        }
        
        //bottomView
        self.hairStackView.removeSubView()
        for i in 0..<self.data.hairWomen.count {
            let itemView = HairView.create(delegate: self, data: self.data.hairWomen[i], index: i)
            self.hairStackView.addArrangedSubview(itemView)
        }
    }
    
    ///CircleViewDelegate
    func pushedButton(sender: CircleView, index: Int) {
        self.index = index
        self.imgView.image = UIImage(named: self.data.hairMen[self.index].photoUrl)
    }
    
    ///HairViewDelegate
    func pushedButton(sender: HairView, index: Int) {
        self.index = index
        self.imgView.image = UIImage(named: self.data.hairWomen[self.index].photoUrl)
    }
}
