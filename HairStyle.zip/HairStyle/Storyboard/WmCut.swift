//
//  WmCut.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/02/25.
//

import UIKit
class WmCut: BaseVC, CircleViewDelegate, HairViewDelegate, FlickViewDelegate {
    
    @IBOutlet weak var flickView: UIView!
    @IBOutlet weak var colorStackView: UIStackView!
    @IBOutlet weak var hairStackView: UIStackView!
    
    override var existsTabBar: Bool { return true }
    let data: HairData = HairData.init()
    private var index: Int = 0
    
    private var frontCard: FlickView!
    private var backCard: FlickView!
    private var flickStartPosition: CGPoint!
    
    ///生成
    static func create() -> WmCut {
        let vc: WmCut = ViewUtil.loadStoryboardVC(storyboard: "WmCut", identifier: "WmCut")
        vc.initialize()
        return vc
    }
    
    ///初期化
    func initialize() {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.renderView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    @IBAction func onClose(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    func renderView() {
        print("WMCut")
        self.frontCard = FlickView.create(delegate: self, data: self.data.hairWomen[self.index], index: self.index, width: self.flickView.width, height: self.flickView.height)
        self.flickView.addSubview(self.frontCard)
        
        //colorView
        self.colorStackView.removeSubView()
        for i in 0..<self.data.colors.count {
            let itemView = CircleView.create(delegate: self, index: i, width: 20.0, backgroundColor: data.colors[i])
            self.colorStackView.addArrangedSubview(itemView)
        }
        
        //bottomView
        self.hairStackView.removeSubView()
        for i in 0..<self.data.hairWomen.count {
            let itemView = HairView.create(delegate: self, data: self.data.hairWomen[i], index: i)
            self.hairStackView.addArrangedSubview(itemView)
        }
    }
    
    ///CircleViewDelegate
    func pushedButton(sender: CircleView, index: Int) {
        self.index = index
        self.backCard = FlickView.create(delegate: self, data: self.data.hairMen[self.index], index: self.index, width: self.flickView.width, height: self.flickView.height)
        self.backCard.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
        self.flickView.insertSubview(self.backCard, belowSubview: self.frontCard)
        
        self.cardRightEffect()
    }
    
    ///HairViewDelegate
    func pushedButton(sender: HairView, index: Int) {
        self.index = index
        self.backCard = FlickView.create(delegate: self, data: self.data.hairWomen[self.index], index: self.index, width: self.flickView.width, height: self.flickView.height)
        self.backCard.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
        self.flickView.insertSubview(self.backCard, belowSubview: self.frontCard)
        
        self.cardLeftEffect()
    }
    
    private func cardLeftEffect() {
        var frontViewTransforms: CGAffineTransform = CGAffineTransform.identity
        var backViewTransforms: CGAffineTransform = CGAffineTransform.identity
        let randomInt = Int.random(in: 1..<101)
        let angle: Double = -0.2 * randomInt
        let angleRadian: CGFloat = CGFloat(.pi / 180 * angle)
        let diffX = (self.flickView.height*sin(abs(angleRadian))) + (self.flickView.width*cos(abs(angleRadian)))
        let moveX: CGFloat = self.flickView.frame.origin.x + diffX
        let moveY: CGFloat = CGFloat((randomInt-30)*2)
        frontViewTransforms = frontViewTransforms.translatedBy(x: -moveX, y: moveY)
        frontViewTransforms = frontViewTransforms.rotated(by: angleRadian)
        self.frontCard.leftMove(parcent: 1)
        backViewTransforms = backViewTransforms.scaledBy(x: 1, y: 1)
        
        UIView.animate(withDuration: 0.5, delay: 0.0, animations: {
            self.frontCard.transform = frontViewTransforms
            self.backCard.transform = backViewTransforms
        }, completion: { (finished: Bool) in
            self.flickView.subviews.forEach {
                $0.removeFromSuperview()
            }
            self.frontCard = self.backCard
            self.backCard = nil
            self.flickView.addSubview(self.frontCard)
        })
    }
    
    private func cardRightEffect() {
        var frontViewTransforms: CGAffineTransform = CGAffineTransform.identity
        var backViewTransforms: CGAffineTransform = CGAffineTransform.identity
        let randomInt = Int.random(in: 1..<101)
        let angle: Double = 0.2 * randomInt
        let angleRadian: CGFloat = CGFloat(.pi / 180 * angle)
        let diffX = (self.flickView.height*sin(abs(angleRadian))) + (self.flickView.width*cos(abs(angleRadian)))
        let moveX: CGFloat = self.flickView.frame.origin.x + diffX
        let moveY: CGFloat = CGFloat((randomInt-30)*2)
        frontViewTransforms = frontViewTransforms.translatedBy(x: moveX, y: moveY)
        frontViewTransforms = frontViewTransforms.rotated(by: angleRadian)
        self.frontCard.rightMove(parcent: 1)
        backViewTransforms = backViewTransforms.scaledBy(x: 1, y: 1)
        
        UIView.animate(withDuration: 0.5, delay: 0.0, animations: {
            self.frontCard.transform = frontViewTransforms
            self.backCard.transform = backViewTransforms
        }, completion: { (finished: Bool) in
            self.flickView.subviews.forEach {
                $0.removeFromSuperview()
            }
            self.frontCard = self.backCard
            self.backCard = nil
            self.flickView.addSubview(self.frontCard)
        })
    }
}
