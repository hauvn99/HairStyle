//
//  WomenTBC.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/03/02.
//

import UIKit
enum TabType: Int {
    case search = 0
    case niced = 1
    case message = 2
    case footprint = 3
    case mypage = 4
}

class WomenTBC: UITabBarController, UITabBarControllerDelegate {
    private(set) static var current: WomenTBC!
    
    static func changeRootVC() {
        WomenTBC.current = ViewUtil.loadStoryboardInitialVC(storyboard: "WomenTBC")
        ViewUtil.changeRootVC(vc: WomenTBC.current)
    }
    override var selectedIndex: Int {
        get { return super.selectedIndex }
        set {
            super.selectedIndex = newValue
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.renderView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.tabBar.items![0].image = UIImage(named: "icon_nav_main_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        self.tabBar.items![1].image = UIImage(named: "icon_nav_keep_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        self.tabBar.items![2].image = UIImage(named: "icon_nav_footprint_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        self.tabBar.items![3].image = UIImage(named: "icon_nav_message_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        self.tabBar.items![4].image = UIImage(named: "icon_nav_mypage_glitter_off")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
     
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        let index = self.viewControllers!.firstIndex(of: viewController)!
        self.tabAnimation(index: index)
    }
    
    private func tabAnimation(index: Int) {
        let imageView = self.tabBar.imageView(index: index)
        let bounceAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
        bounceAnimation.values = [1.0 ,1.4, 0.9, 1.15, 0.95, 1.02, 1.0]
        bounceAnimation.duration = TimeInterval(0.5)
        bounceAnimation.calculationMode = CAAnimationCalculationMode.cubic
        imageView.layer.add(bounceAnimation, forKey: nil)
    }
    
    private func moveTab(index: Int) {
        self.popToSelf()
        self.selectedIndex = index
    }
    
    @IBAction func onClose(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    //タブバー作成
    func createTabBar(){
        let line = UIView.init(frame: CGRect.init(x: 0, y: -0.5, width: DeviceUtil.screenWidth, height: 1))
        line.backgroundColor = Color.darkGrayishPurple10
        self.tabBar.addSubview(line)
        self.tabBar.barTintColor = Color.paleGray
        self.tabBar.backgroundColor = Color.paleGray
        self.tabBar.tintColor = Color.deepPurple
        //非選択タブのフォント設定
        let attrsNormal = [
            NSAttributedString.Key.foregroundColor: Color.darkGray,
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 10.0, weight: .bold)
        ]
        UITabBarItem.appearance().setTitleTextAttributes(attrsNormal, for: .normal)
        //選択中タブのフォント設定
        let attrsSelected = [
            NSAttributedString.Key.foregroundColor: Color.deepPurple,
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 10.0, weight: .bold)
        ]
        UITabBarItem.appearance().setTitleTextAttributes(attrsSelected, for: .selected)
        self.viewControllers?.forEach { $0.tabBarItem.title = ls($0.tabBarItem.title!) }
    }
    
    func renderView() {
        print("WomenTBC")
        self.createTabBar()
        // Set up the Tab Bar Controller to have two tabs
        //let tabBarController = UITabBarController()
        //self.viewControllers = [SearchVC, NicedVC]
        //self.selectedIndex = TabType.search.rawValue
//        self.moveTab(index: TabType.search.rawValue)
//        let vc = SearchResult()
//        vc.view.backgroundColor = .red
//        navigationController?.pushViewController(vc, animated: true)
    }
    
    
}

