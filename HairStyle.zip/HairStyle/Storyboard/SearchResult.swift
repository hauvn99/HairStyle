//
//  SearchResult.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/03/03.
//

import UIKit

class SearchResult: BaseVC, UITableViewDataSource, UITableViewDelegate, HairCellDelegate {
    override var existsTabBar: Bool { return true }
    @IBOutlet weak var tableView: UITableView!
    private var data: [HairItemData] = []
    
    ///生成
    static func create() -> SearchResult {
        let vc: SearchResult = ViewUtil.loadStoryboardVC(storyboard: "SearchResult", identifier: "SearchResult")
        return vc
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.register(UINib(nibName: "HairCell", bundle: nil), forCellReuseIdentifier: "HairCell")
        self.renderView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    @IBAction func onClose(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "HairCell", for: indexPath) as! HairCell
        if indexPath.row < self.data.count {
            cell.config(delegate: self, data: self.data[indexPath.row])
            cell.backgroundColor = UIColor.clear
            cell.selectionStyle = .none
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func renderView() {
        print("WmHome")
        self.renderData()
        self.tableView.reloadData()
    }
    
    func renderData() {
        self.tableView.tableHeaderView = nil
        self.tableView.tableFooterView = nil
        self.data.removeAll()
        
        for i in 0..<10 {
            self.data.append(HairItemData(photoUrl: "dog\(i+1)"))
        }
        print(self.data)
    }
}
