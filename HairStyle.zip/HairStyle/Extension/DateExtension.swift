//
//  DateExtension.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/29.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension Date {
    var year: Int { return self.dateComponents.year! }
    var month: Int {  return self.dateComponents.month! }
    var day: Int { return self.dateComponents.day! }
    private var dateComponents: DateComponents {
        let calendar = NSCalendar(identifier: NSCalendar.Identifier.gregorian)!
        let unitFlag: NSCalendar.Unit = [.year, .month, .day]
        return calendar.components(unitFlag, from: self)
    }
    
    init?(string: String, format: String) {
        let formatter = Date.createFormatter(format: format)
        let date = formatter.date(from: string)
        if date == nil {
            return nil
        } else {
            self = date!
        }
    }
    
    init(year: Int, month: Int, day: Int = 1) {
        self.init(string: String(format: "%04d%02d%02d", year, month, day), format: "yyyyMMdd")!
    }

    func string(format: String) -> String {
        let formatter = Date.createFormatter(format: format)
        return formatter.string(from: self)
    }
    
    static private func createFormatter(format: String) -> DateFormatter {
        let formatter: DateFormatter = DateFormatter()
        formatter.dateFormat = format
        formatter.locale = Locale(identifier: "en_US_POSIX")
        return formatter
    }
}
