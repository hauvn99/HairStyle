//
//  UIPickerView.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/30.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension UIPickerView {
    func stopScroll() {
        if let componentCount = self.dataSource?.numberOfComponents(in: self) {
            for component in 0..<componentCount {
                self.selectRow(self.selectedRow(inComponent: component), inComponent: component, animated: false)
            }
        }
    }
}
