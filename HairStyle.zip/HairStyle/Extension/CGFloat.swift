//
//  CGFloat.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/15.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension CGFloat {
    var int: Int { return Int(self) }
    var string: String { return String(describing: self) }
    
    ///Int
    static func + (left: CGFloat, right: Int) -> CGFloat {
        return left + CGFloat(right)
    }
    
    static func - (left: CGFloat, right: Int) -> CGFloat {
        return left - CGFloat(right)
    }
    
    static func * (left: CGFloat, right: Int) -> CGFloat {
        return left * CGFloat(right)
    }
    
    static func / (left: CGFloat, right: Int) -> CGFloat {
        return left / CGFloat(right)
    }
    
    static func += (left: inout CGFloat, right: Int) {
        left = left + right
    }
    
    static func -= (left: inout CGFloat, right: Int) {
        left = left - right
    }
    
    static func *= (left: inout CGFloat, right: Int) {
        left = left * right
    }
    
    static func /= (left: inout CGFloat, right: Int) {
        left = left / right
    }
    
    //Float
    static func + (left: CGFloat, right: Float) -> CGFloat {
        return left + CGFloat(right)
    }
    
    static func - (left: CGFloat, right: Float) -> CGFloat {
        return left - CGFloat(right)
    }
    
    static func * (left: CGFloat, right: Float) -> CGFloat {
        return left * CGFloat(right)
    }
    
    static func / (left: CGFloat, right: Float) -> CGFloat {
        return left / CGFloat(right)
    }

    static func += (left: inout CGFloat, right: Float) {
        left = left + right
    }
    
    static func -= (left: inout CGFloat, right: Float) {
        left = left - right
    }
    
    static func *= (left: inout CGFloat, right: Float) {
        left = left * right
    }
    
    static func /= (left: inout CGFloat, right: Float) {
        left = left / right
    }
    
    ///Double
    static func + (left: CGFloat, right: Double) -> CGFloat {
        return left + CGFloat(right)
    }
    
    static func - (left: CGFloat, right: Double) -> CGFloat {
        return left - CGFloat(right)
    }
    
    static func * (left: CGFloat, right: Double) -> CGFloat {
        return left * CGFloat(right)
    }
    
    static func / (left: CGFloat, right: Double) -> CGFloat {
        return left / CGFloat(right)
    }

    static func += (left: inout CGFloat, right: Double) {
        left = left + right
    }
    
    static func -= (left: inout CGFloat, right: Double) {
        left = left - right
    }
    
    static func *= (left: inout CGFloat, right: Double) {
        left = left * right
    }
    
    static func /= (left: inout CGFloat, right: Double) {
        left = left / right
    }
}
