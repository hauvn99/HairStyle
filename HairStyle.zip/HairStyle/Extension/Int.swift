//
//  Int.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/15.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension Int {
    var cgf: CGFloat { return CGFloat(self) }
    
    var string: String { return String(self) }

    //Float
    static func + (left: Int, right: Float) -> Float {
        return Float(left) + right
    }

    static func - (left: Int, right: Float) -> Float {
        return Float(left) - right
    }

    static func * (left: Int, right: Float) -> Float {
        return Float(left) * right
    }

    static func / (left: Int, right: Float) -> Float {
        return Float(left) / right
    }
    
    static func += (left: inout Int, right: Float) {
        left = Int(left + right)
    }
    
    static func -= (left: inout Int, right: Float) {
        left = Int(left - right)
    }
    
    static func *= (left: inout Int, right: Float) {
        left = Int(left * right)
    }
    
    static func /= (left: inout Int, right: Float) {
        left = Int(left / right)
    }
    
    //Double
    static func + (left: Int, right: Double) -> Double {
        return Double(left) + right
    }
    
    static func - (left: Int, right: Double) -> Double {
        return Double(left) - right
    }
    
    static func * (left: Int, right: Double) -> Double {
        return Double(left) * right
    }
    
    static func / (left: Int, right: Double) -> Double {
        return Double(left) / right
    }

    static func += (left: inout Int, right: Double) {
        left = Int(left + right)
    }
    
    static func -= (left: inout Int, right: Double) {
        left = Int(left - right)
    }
    
    static func *= (left: inout Int, right: Double) {
        left = Int(left * right)
    }
    
    static func /= (left: inout Int, right: Double) {
        left = Int(left / right)
    }
    
    //CGFloat
    static func + (left: Int, right: CGFloat) -> CGFloat {
        return CGFloat(left) + right
    }
    
    static func - (left: Int, right: CGFloat) -> CGFloat {
        return CGFloat(left) - right
    }
    
    static func * (left: Int, right: CGFloat) -> CGFloat {
        return CGFloat(left) * right
    }
    
    static func / (left: Int, right: CGFloat) -> CGFloat {
        return CGFloat(left) / right
    }

    static func += (left: inout Int, right: CGFloat) {
        left = Int(left + right)
    }
    
    static func -= (left: inout Int, right: CGFloat) {
        left = Int(left - right)
    }
    
    static func *= (left: inout Int, right: CGFloat) {
        left = Int(left * right)
    }
    
    static func /= (left: inout Int, right: CGFloat) {
        left = Int(left / right)
    }
}
