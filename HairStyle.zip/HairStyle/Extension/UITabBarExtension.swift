//
//  UITabBarExtension.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2021/01/08.
//  Copyright © 2021 Hau Nguyen. All rights reserved.
//
import UIKit

extension UITabBar {
    func imageView(index: Int) -> UIImageView {
        return (self.tabBarButton(index: index).subviews.filter { String(describing: type(of: $0)) == "UITabBarSwappableImageView" })[0] as! UIImageView
    }

    private func tabBarButton(index: Int) -> UIView {
        return (self.subviews.filter { String(describing: type(of: $0)) == "UITabBarButton" })[index]
    }
}
extension UITabBarItem {
    var tabBarView : UIView { return self.value(forKey: "view") as! UIView }
}

