//
//  UIView.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/04/30.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension UIView{
    
    // https://qiita.com/xxminamixx/items/ee8435a4e07d31cf28fd
    /// 枠線の色
    @IBInspectable var borderColor: UIColor? {
        get {
            return layer.borderColor.map { UIColor(cgColor: $0) }
        }
        set {
            layer.borderColor = newValue?.cgColor
        }
    }

    /// 枠線のWidth
    @IBInspectable var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }

    /// 角丸の大きさ
    @IBInspectable var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = newValue > 0
        }
    }

    /// 影の色
    @IBInspectable var shadowColor: UIColor? {
        get {
            return layer.shadowColor.map { UIColor(cgColor: $0) }
        }
        set {
            layer.shadowColor = newValue?.cgColor
            layer.masksToBounds = false
        }
    }

    /// 影の透明度
    @IBInspectable var shadowAlpha: Float {
        get {
            return layer.shadowOpacity
        }
        set {
            layer.shadowOpacity = newValue
        }
    }

    /// 影のオフセット
    @IBInspectable var shadowOffset: CGSize {
        get {
            return layer.shadowOffset
        }
        set {
            layer.shadowOffset = newValue
        }
    }

    /// 影のぼかし量
    @IBInspectable var shadowRadius: CGFloat {
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }
    
    ///subViewをすべてremoveする
    func removeSubView() {
        for subview in self.subviews {
            subview.removeFromSuperview() }
    }
    
    ///丸コーナー
    func cornerRadius(length: CGFloat) {
        self.layer.cornerRadius = length * DeviceUtil.basicRatio
        self.clipsToBounds = true
    }
    
    ///円形
    func changeCircle() {
        self.cornerRadius(length: min(self.width, self.height) / 2)
    }
    
    ///拡大縮小アニメーション
    func scaleAnimation(duration: TimeInterval, delay: TimeInterval = 0, scale: [Double]) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            let bounceAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
            bounceAnimation.values = scale
            bounceAnimation.duration = TimeInterval(duration)
            bounceAnimation.calculationMode = CAAnimationCalculationMode.cubic
            self.layer.add(bounceAnimation, forKey: nil)
        }
    }
    
    // transform
    @IBInspectable var transformScale: CGFloat {
        get {
            fatalError()
        }
        set {
            self.transform = CGAffineTransform(scaleX: newValue, y: newValue)
        }
    }
    
    ///UIStackViewから削除する
    func removeFromStackView() {
        guard let stackView = self.superview as? UIStackView  else { return }
        stackView.removeArrangedSubview(self)
        self.removeFromSuperview()
    }
    
    ///指定したクラスタイプのViewを持っているか
    func hasSubview(viewType: UIView.Type) -> Bool {
        if type(of: self) == viewType { return true }
        for subview in self.subviews {
            if subview.hasSubview(viewType: viewType) { return true }
        }
        return false
    }

    /* baseが付かないproperty */
    
    var width : CGFloat {
        get { return self.frame.size.width }
        set { self.frame.size.width = newValue }
    }
    
    var height : CGFloat {
        get { return self.frame.size.height }
        set { self.frame.size.height = newValue }
    }
    
    var aspectRatio : CGFloat { return self.width == 0 ? 0 : self.height / self.width }
    
    var size : CGSize {
        get { return self.frame.size }
        set { self.frame.size = newValue }
    }
    
    var left : CGFloat {
        get { return self.frame.origin.x }
        set { self.frame.origin.x = newValue }
    }
    
    var right : CGFloat {
        get { return self.frame.origin.x + self.width }
        set { self.frame.origin.x = newValue - self.width }
    }
    
    var top : CGFloat {
        get { return self.frame.origin.y }
        set { self.frame.origin.y = newValue }
    }
    
    var bottom : CGFloat {
        get { return self.frame.origin.y + self.height }
        set { self.frame.origin.y = newValue - self.height }
    }
    
    var centerX : CGFloat {
        get { return self.frame.origin.x + self.width / 2 }
        set { self.frame.origin.x = newValue - self.width / 2 }
    }

    var centerY : CGFloat {
        get { return self.frame.origin.y + self.height / 2 }
        set { self.frame.origin.y = newValue - self.height / 2 }
    }

    var topLeft : CGPoint {
        get { return CGPoint(x: self.left, y: self.top) }
        set { self.left = newValue.x
            self.top = newValue.y }
    }

    var topCenter : CGPoint {
        get { return CGPoint(x: self.centerX, y: self.top) }
        set {
            self.centerX = newValue.x
            self.top = newValue.y
        }
    }

    var topRight : CGPoint {
        get { return CGPoint(x: self.right, y: self.top) }
        set {
            self.right = newValue.x
            self.top = newValue.y
        }
    }
    
    var centerLeft : CGPoint {
        get { return CGPoint(x: self.left, y: self.centerY) }
        set {
            self.left = newValue.x
            self.centerY = newValue.y
        }
    }
    
    var centerRight : CGPoint {
        get { return CGPoint(x: self.right, y: self.centerY) }
        set {
            self.right = newValue.x
            self.centerY = newValue.y
        }
    }
    
    var bottomLeft : CGPoint {
        get { return CGPoint(x: self.left, y: self.bottom) }
        set {
            self.left = newValue.x
            self.bottom = newValue.y
        }
    }
    
    var bottomCenter : CGPoint {
        get { return CGPoint(x: self.centerX, y: self.bottom) }
        set {
            self.centerX = newValue.x
            self.bottom = newValue.y
        }
    }
    
    var bottomRight : CGPoint {
        get { return CGPoint(x: self.right, y: self.bottom) }
        set {
            self.right = newValue.x
            self.bottom = newValue.y
        }
    }
    
    var halfWidth : CGFloat { return self.width / 2 }
    var halfHeight : CGFloat { return self.height / 2 }
    var halfPoint : CGPoint { return CGPoint(x: self.halfWidth, y: self.halfHeight) }
    var halfSize : CGSize { return CGSize(width: self.halfWidth, height: self.halfHeight) }

    /* 以下、4.7inchとみなした時のサイズ */
    
    var baseFrame : CGRect {
        get { return self.frame / DeviceUtil.basicRatio }
        set { self.frame = newValue * DeviceUtil.basicRatio }
    }
    
    var baseWidth : CGFloat {
        get { return self.width / DeviceUtil.basicRatio }
        set { self.width = newValue * DeviceUtil.basicRatio }
    }
    
    var baseHeight : CGFloat {
        get { return self.height / DeviceUtil.basicRatio }
        set { self.height = newValue * DeviceUtil.basicRatio }
    }
    
    var baseSize : CGSize {
        get { return self.frame.size / DeviceUtil.basicRatio }
        set { self.frame.size = newValue * DeviceUtil.basicRatio }
    }
    
    var baseLeft : CGFloat {
        get { return self.left / DeviceUtil.basicRatio }
        set { self.left = newValue * DeviceUtil.basicRatio }
    }
    
    var baseRight : CGFloat {
        get { return self.right / DeviceUtil.basicRatio }
        set { self.right = newValue * DeviceUtil.basicRatio }
    }
    
    var baseTop : CGFloat {
        get { return self.top / DeviceUtil.basicRatio }
        set { self.top = newValue * DeviceUtil.basicRatio }
    }
    
    var baseBottom : CGFloat {
        get { return self.bottom / DeviceUtil.basicRatio }
        set { self.bottom = newValue * DeviceUtil.basicRatio }
    }
    
    var baseCenterX : CGFloat {
        get { return self.centerX / DeviceUtil.basicRatio }
        set { self.centerX = newValue * DeviceUtil.basicRatio }
    }
    
    var baseCenterY : CGFloat {
        get { return self.centerY / DeviceUtil.basicRatio }
        set { self.centerY = newValue * DeviceUtil.basicRatio }
    }
    
    var baseTopLeft : CGPoint {
        get { return self.topLeft / DeviceUtil.basicRatio }
        set { self.topLeft = newValue * DeviceUtil.basicRatio }
    }
    
    var baseTopCenter : CGPoint {
        get { return self.topCenter / DeviceUtil.basicRatio }
        set { self.topCenter = newValue * DeviceUtil.basicRatio }
    }
    
    var baseTopRight : CGPoint {
        get { return self.topRight / DeviceUtil.basicRatio }
        set { self.topRight = newValue * DeviceUtil.basicRatio }
    }
    
    var baseCenterLeft : CGPoint {
        get { return self.centerLeft / DeviceUtil.basicRatio }
        set { self.centerLeft = newValue * DeviceUtil.basicRatio }
    }
    
    var baseCenter : CGPoint {
        get { return self.center / DeviceUtil.basicRatio }
        set { self.center = newValue * DeviceUtil.basicRatio }
    }
    
    var baseCenterRight : CGPoint {
        get { return self.centerRight / DeviceUtil.basicRatio }
        set { self.centerRight = newValue * DeviceUtil.basicRatio }
    }
    
    var baseBottomLeft : CGPoint {
        get { return self.bottomLeft / DeviceUtil.basicRatio }
        set { self.bottomLeft = newValue * DeviceUtil.basicRatio }
    }
    
    var baseBottomCenter : CGPoint {
        get { return self.bottomCenter / DeviceUtil.basicRatio }
        set { self.bottomCenter = newValue * DeviceUtil.basicRatio }
    }
    
    var baseBottomRight : CGPoint {
        get { return self.bottomRight / DeviceUtil.basicRatio }
        set { self.bottomRight = newValue * DeviceUtil.basicRatio }
    }
    
    var baseHalfWidth : CGFloat { return self.halfWidth / DeviceUtil.basicRatio }
    var baseHalfHeight : CGFloat { return self.halfHeight / DeviceUtil.basicRatio }
    var baseHalfPoint : CGPoint { return self.halfPoint / DeviceUtil.basicRatio }
    var baseHalfSize : CGSize { return self.halfSize / DeviceUtil.basicRatio }
}
