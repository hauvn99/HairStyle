//
//  UIViewController.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/30.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension UIViewController {
    var hasModal : Bool { return self.presentedViewController != nil }
    var isModal : Bool { return self.presentingViewController != nil }

    var topVC: UIViewController {
        if let viewController = self.presentedViewController {
            return viewController.topVC
        }
        if let viewController = self as? UINavigationController {
            return viewController.topViewController!.topVC
        }
        if let viewController = self as? UITabBarController {
            return viewController.selectedViewController!.topVC
        }
        return self
    }

    ///自分までPopする
    func popToSelf() {
        var nextVC: UIViewController!
        if self.hasModal {
            nextVC = self.presentedViewController
        } else if self is UINavigationController {
            nextVC = (self as! UINavigationController).topViewController
        } else if self is UITabBarController {
            nextVC = (self as! UITabBarController).selectedViewController!
        }
        if nextVC != nil {
            nextVC.popToSelf()
        }
        
        if self.hasModal {
            self.dismiss(animated: false, completion: nil)
        } else if let navi = self as? UINavigationController {
            navi.popToRootViewController(animated: false)
        } else if let navi = self.navigationController {
            navi.popToViewController(self, animated: false)
        }
    }
    
    ///指定したクラスタイプのVCまでPop
    func popTo(vcType: UIViewController.Type, animated: Bool = true) -> Bool {
        guard let navi = self.navigationController else { return false }
        for vc in navi.viewControllers.reversed() {
            if type(of: vc) == vcType {
                navi.popToViewController(vc, animated: animated)
                return true
            }
        }
        return false
    }
    
    ///透過でPresent
    func presentVC(vc: UIViewController, animated: Bool = false, completion: (() -> Void)? = nil) {
        vc.modalPresentationStyle = .overCurrentContext
        vc.modalPresentationCapturesStatusBarAppearance = true
        self.present(vc, animated: animated, completion: completion)
    }
}
