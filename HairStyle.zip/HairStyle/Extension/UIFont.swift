//
//  UIFont.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/27.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension UIFont {
    static func createFont(ofSize fontSize: CGFloat, isBold: Bool = false) -> UIFont {
        if isBold {
            return UIFont.boldSystemFont(ofSize: fontSize)
        }else{
            return UIFont.systemFont(ofSize: fontSize)
        }
    }

    static func createBoldFont(ofSize fontSize: CGFloat) -> UIFont {
        return UIFont.createFont(ofSize: fontSize, isBold: true)
    }
}
