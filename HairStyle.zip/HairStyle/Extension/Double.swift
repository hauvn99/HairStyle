//
//  Double.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/15.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension Double {
    public var int: Int { return Int(self) }
    public var cgf: CGFloat { return CGFloat(self) }
    
    //Int
    static func + (left: Double, right: Int) -> Double {
        return left + Double(right)
    }
    
    static func - (left: Double, right: Int) -> Double {
        return left - Double(right)
    }
    
    static func * (left: Double, right: Int) -> Double {
        return left * Double(right)
    }
    
    static func / (left: Double, right: Int) -> Double {
        return left / Double(right)
    }
    
    static func += (left: inout Double, right: Int) {
        left = left + right
    }
    
    static func -= (left: inout Double, right: Int) {
        left = left - right
    }
    
    static func *= (left: inout Double, right: Int) {
        left = left * right
    }
    
    static func /= (left: inout Double, right: Int) {
        left = left / right
    }
    
    //Float
    static func + (left: Double, right: Float) -> Double {
        return left + Double(right)
    }
    
    static func - (left: Double, right: Float) -> Double {
        return left - Double(right)
    }
    
    static func * (left: Double, right: Float) -> Double {
        return left * Double(right)
    }
    
    static func / (left: Double, right: Float) -> Double {
        return left / Double(right)
    }
    
    static func += (left: inout Double, right: Float) {
        left = left + right
    }
    
    static func -= (left: inout Double, right: Float) {
        left = left - right
    }
    
    static func *= (left: inout Double, right: Float) {
        left = left * right
    }
    
    static func /= (left: inout Double, right: Float) {
        left = left / right
    }
    
    //CGFloat
    static func + (left: Double, right: CGFloat) -> CGFloat {
        return CGFloat(left) + right
    }
    
    static func - (left: Double, right: CGFloat) -> CGFloat {
        return CGFloat(left) - right
    }
    
    static func * (left: Double, right: CGFloat) -> CGFloat {
        return CGFloat(left) * right
    }
    
    static func / (left: Double, right: CGFloat) -> CGFloat {
        return CGFloat(left) / right
    }

    static func += (left: inout Double, right: CGFloat) {
        left = Double(left + right)
    }
    
    static func -= (left: inout Double, right: CGFloat) {
        left = Double(left - right)
    }
    
    static func *= (left: inout Double, right: CGFloat) {
        left = Double(left * right)
    }
    
    static func /= (left: inout Double, right: CGFloat) {
        left = Double(left / right)
    }
}

