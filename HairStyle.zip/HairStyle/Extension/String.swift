//
//  String.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/15.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit
import Foundation

extension String {
    ///文字列が存在するか
    static func exists(string: String?) -> Bool {
        return string != nil && !string!.isEmpty
    }
    
    ///nullまたはから文字列
    static func noString(string: String?) -> Bool {
        return !String.exists(string: string)
    }
    
    ///文字列が存在するか
    var hasLength : Bool { return !self.isEmpty }
    
    ///文字列の長さ
    var length: Int {
        return self.count
    }

    ///特定の文字列を削除
    func remove(_ text: String) -> String {
        return self.replacingOccurrences(of: text, with: "")
    }
    
    ///A=>\u0041;
    var htmlUnicodeHexString : String {
        return (self.unicodeScalars.map { "\\u{" + String($0.value, radix: 16) + "}" }).joined()
    }
    
    ///正規表現で検索
    func regMatch(pattern: String, options: NSRegularExpression.Options = []) -> Bool {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: options) else {
            return false
        }
        let matches = regex.matches(in: self, options: [], range: NSMakeRange(0, self.count))
        return matches.count > 0
    }
    
    ///正規表現で置換
    func regReplace(pattern: String, with: String, options: NSRegularExpression.Options = []) -> String {
        let regex = try! NSRegularExpression(pattern: pattern, options: options)
        return regex.stringByReplacingMatches(in: self, options: [], range: NSMakeRange(0, self.count), withTemplate: with)
    }
    
    ///正規表現からRangeの配列を取得
    func regMatchToRange(pattern: String, options: NSRegularExpression.Options = []) -> [NSRange] {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: options) else {
            return [NSRange]()
        }
        let matches = regex.matches(in: self, options: [], range: NSMakeRange(0, self.count))
        var range = [NSRange]()
        for i in 0..<matches.count {
            for j in 0 ..< matches[i].numberOfRanges {
                range.append(matches[i].range(at: j))
            }
        }
        return range
    }

    ///数値変換
    var int: Int { return Int(self)! }

    ///0始まりは含めない
    var isNumber: Bool { return self.regMatch(pattern: "^[1-9]\\d*$") }
    
    ///英数字かどうか
    var isAlphanumeric: Bool { return self.regMatch(pattern: "^[a-zA-Z0-9]+$") }
    
    ///text.substring(1...5)
    func substring(_ r: CountableRange<Int>) -> String {
        let length = self.count
        let fromIndex = (r.startIndex > 0) ? self.index(self.startIndex, offsetBy: r.startIndex) : self.startIndex
        let toIndex = (length > r.endIndex) ? self.index(self.startIndex, offsetBy: r.endIndex) : self.endIndex
        if fromIndex >= self.startIndex && toIndex <= self.endIndex {
            return String(self[fromIndex..<toIndex])
        }
        return String(self)
    }
   
    ///text.substring(1..<5)
    func substring(_ r: CountableClosedRange<Int>) -> String {
        let from = r.lowerBound
        let to = r.upperBound
        return self.substring(from..<(to+1))
    }
    
    ///text.substring(1...)
    func substring(_ r: CountablePartialRangeFrom<Int>) -> String {
        let from = r.lowerBound
        let to = self.count
        return self.substring(from..<to)
    }
    
    ///text.substring(...5)
    func substring(_ r: PartialRangeThrough<Int>) -> String {
        let from = 0
        let to = r.upperBound
        return self.substring(from..<to)
    }

    
    ///NSString
    private var ns: NSString { return (self as NSString) }
    public func substring(from index: Int) -> String { return self.ns.substring(from: index) }
    public func substring(to index: Int) -> String { return self.ns.substring(to: index) }
    public func substring(with range: NSRange) -> String { return self.ns.substring(with: range) }
    public var lastPathComponent: String { return self.ns.lastPathComponent }
    public var pathExtension: String { return self.ns.pathExtension }
    public var deletingLastPathComponent: String { return self.ns.deletingLastPathComponent }
    public var deletingPathExtension: String { return self.ns.deletingPathExtension }
    public var pathComponents: [String] { return self.ns.pathComponents }
    public func appendingPathComponent(_ str: String) -> String { return self.ns.appendingPathComponent(str) }
    public func appendingPathExtension(_ str: String) -> String? { return self.ns.appendingPathExtension(str) }
    public func replacingCharacters(in: NSRange, with: String) -> String { return self.ns.replacingCharacters(in: `in`, with: with) }
    public func range(of: String) -> NSRange { return self.ns.range(of: of) }
    
    // localize用のString拡張
    var localized: String {
        return NSLocalizedString(self, tableName: nil, bundle: Bundle.main, value: "", comment: "")
    }
    // get width of string with font
    func widthOfString(usingFont font: UIFont) -> CGFloat {
        let fontAttributes = [NSAttributedString.Key.font: font]
        let size = self.size(withAttributes: fontAttributes)
        return size.width
    }
    // get height of string with font
    func heightOfString(usingFont font: UIFont) -> CGFloat {
        let fontAttributes = [NSAttributedString.Key.font: font]
        let size = self.size(withAttributes: fontAttributes)
        return size.height
    }
    // get size of string with font
    func sizeOfString(usingFont font: UIFont) -> CGSize {
        let fontAttributes = [NSAttributedString.Key.font: font]
        return self.size(withAttributes: fontAttributes)
    }
    
    func heightWithConstrainedWidth(width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: [NSAttributedString.Key.font: font], context: nil)
        return boundingBox.height
    }
}
