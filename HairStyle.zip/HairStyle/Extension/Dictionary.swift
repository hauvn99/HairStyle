//
//  Dictionary.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/26.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension Dictionary where Key: ExpressibleByStringLiteral, Value: Any {
    mutating func overlap(dictionary: Dictionary) {
        for (key, value) in dictionary {
            self[key] = value
        }
    }
    
    //キーが存在するか
    func hasKey(_ key: Key) -> Bool {
        return self[key] != nil
    }
    
    func string(_ key: String) -> String {
        if self[key as! Key] is NSNull {
            return ""
        } else if let value : String = self[key as! Key] as? String {
            return value
        } else {
            return String(self.int(key))
        }
    }
    
    func stringNil(_ key: String) -> String? {
        return self[key as! Key] == nil ? nil : self.string(key)
    }
    
    func stringDefault(_ key: String, defaultValue: String = "") -> String {
        return self[key as! Key] == nil ? defaultValue : self.string(key)
    }
    
    func int(_ key: String) -> Int {
        if let value : Int = self[key as! Key] as? Int {
            return value
        } else {
            return Int(self.string(key))!
        }
    }
    
    func intDefault(_ key: String, defaultValue: Int = 0) -> Int {
        return self[key as! Key] == nil ? defaultValue : self.int(key)
    }

    func bool(_ key: String) -> Bool {
        if let value : Bool = self[key as! Key] as? Bool {
            return value
        } else {
            return self.string(key) == "1"
        }
    }

    func double(_ key: String) -> Double {
        if let value: Int = self[key as! Key] as? Int {
            return Double(value)
        }
        else {
            return Double(0)
        }
    }

    func boolDefault(_ key: String, defaultValue: Bool = false) -> Bool {
        return self[key as! Key] == nil ? defaultValue : self.bool(key)
    }
    
    func array(_ key: String) -> [[String:Any]] {
        return self[key as! Key] as! [[String:Any]]
    }
    
    func singleArray(_ key: String) -> [String:Any] {
        return self[key as! Key] as! [String:Any]
    }
}
