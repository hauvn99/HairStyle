//
//  CGRect.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/15.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension CGRect {
    static func * (left: CGRect, right: CGFloat) -> CGRect {
        return CGRect(origin: left.origin * right, size: left.size * right)
    }
    
    static func / (left: CGRect, right: CGFloat) -> CGRect {
        return CGRect(origin: left.origin / right, size: left.size / right)
    }
    
    static func *= (left: inout CGRect, right: CGFloat) {
        left = left * right
    }

    static func /= (left: inout CGRect, right: CGFloat) {
        left = left / right
    }
}
