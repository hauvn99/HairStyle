//
//  Bool.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/15.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension Bool {
    mutating func toggle() {
        self = !self
    }
    
    var apiValue: String { return self ? "1" : "0" }
}
