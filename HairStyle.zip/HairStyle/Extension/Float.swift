//
//  Float.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/15.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension Float{
    public var cgf: CGFloat { return CGFloat(self) }

    //Int
    static func + (left: Float, right: Int) -> Float {
        return left + Float(right)
    }
    
    static func - (left: Float, right: Int) -> Float {
        return left - Float(right)
    }
    
    static func * (left: Float, right: Int) -> Float {
        return left * Float(right)
    }
    
    static func / (left: Float, right: Int) -> Float {
        return left / Float(right)
    }
    
    static func += (left: inout Float, right: Int) {
        left = left + right
    }
    
    static func -= (left: inout Float, right: Int) {
        left = left - right
    }
    
    static func *= (left: inout Float, right: Int) {
        left = left * right
    }
    
    static func /= (left: inout Float, right: Int) {
        left = left / right
    }
    
    //Double
    static func + (left: Float, right: Double) -> Double {
        return Double(left) + right
    }
    
    static func - (left: Float, right: Double) -> Double {
        return Double(left) - right
    }
    
    static func * (left: Float, right: Double) -> Double {
        return Double(left) * right
    }
    
    static func / (left: Float, right: Double) -> Double {
        return Double(left) / right
    }
    
    static func += (left: inout Float, right: Double) {
        left = Float(left + right)
    }
    
    static func -= (left: inout Float, right: Double) {
        left = Float(left - right)
    }
    
    static func *= (left: inout Float, right: Double) {
        left = Float(left * right)
    }
    
    static func /= (left: inout Float, right: Double) {
        left = Float(left / right)
    }
    
   //CGFloat
    static func + (left: Float, right: CGFloat) -> CGFloat {
        return CGFloat(left) + right
    }
    
    static func - (left: Float, right: CGFloat) -> CGFloat {
        return CGFloat(left) - right
    }
    
    static func * (left: Float, right: CGFloat) -> CGFloat {
        return CGFloat(left) * right
    }
    
    static func / (left: Float, right: CGFloat) -> CGFloat {
        return CGFloat(left) / right
    }
    
    static func += (left: inout Float, right: CGFloat) {
        left = Float(left + right)
    }
    
    static func -= (left: inout Float, right: CGFloat) {
        left = Float(left - right)
    }
    
    static func *= (left: inout Float, right: CGFloat) {
        left = Float(left * right)
    }
    
    static func /= (left: inout Float, right: CGFloat) {
        left = Float(left / right)
    }
}
