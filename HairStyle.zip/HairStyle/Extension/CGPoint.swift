//
//  CGPoint.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/15.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension CGPoint {
    static func + (left: CGPoint, right: CGSize) -> CGPoint {
        return CGPoint(x: left.x + right.width, y: left.y + right.height)
    }

    static func - (left: CGPoint, right: CGSize) -> CGPoint {
        return CGPoint(x: left.x - right.width, y: left.y - right.height)
    }
    
    static func * (left: CGPoint, right: CGFloat) -> CGPoint {
        return CGPoint(x: left.x * right, y: left.y * right)
    }
    
    static func / (left: CGPoint, right: CGFloat) -> CGPoint {
        return CGPoint(x: left.x / right, y: left.y / right)
    }
    
    static func += ( left: inout CGPoint, right: CGSize) {
        left = left + right
    }
    
    static func -= ( left: inout CGPoint, right: CGSize) {
        left = left - right
    }

    static func  *= ( left: inout CGPoint, right: CGFloat) {
        left = left * right
    }
    
    static func  /= ( left: inout CGPoint, right: CGFloat) {
        left = left / right
    }
}
