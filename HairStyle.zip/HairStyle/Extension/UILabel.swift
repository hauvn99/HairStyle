//
//  UILabel.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/30.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

extension UILabel {
    class func createLabel(text: String, color: UIColor, fontSize: CGFloat, weight: CGFloat = UIFont.Weight.regular.rawValue) -> UILabel {
        let label = UILabel()
        label.textColor = color
        label.font = UIFont.systemFont(ofSize: fontSize, weight: UIFont.Weight(rawValue: weight))
        label.text = text
        label.sizeToFit()
        return label
    }
    
    class func createBoldLabel(text: String, color: UIColor, fontSize: CGFloat) -> UILabel {
        return UILabel.createLabel(text: text, color: color, fontSize: fontSize, weight: UIFont.Weight.bold.rawValue)
    }
    
    func changeRegular() {
        self.font = UIFont.systemFont(ofSize: self.font.pointSize, weight: .regular)
    }
    
    func changeBold() {
        self.font = UIFont.systemFont(ofSize: self.font.pointSize, weight: .bold)
    }
    
    func changeWeight(isBold: Bool) {
        self.font = UIFont.systemFont(ofSize: self.font.pointSize, weight: isBold ? .bold : .regular)
    }
    
    ///下線を追加
    func setUnderLine() {
        self.setAttribute(attribute: [NSAttributedString.Key(rawValue: NSAttributedString.Key.underlineStyle.rawValue): NSUnderlineStyle.single.rawValue], string: self.text!)
    }
    
    ///特定の文字列の色を変更する
    func setColorAttribute(color: UIColor, string: String) {
        self.setAttribute(attribute: [NSAttributedString.Key(rawValue: NSAttributedString.Key.foregroundColor.rawValue): color], string: string)
    }
    
    func setBoldFontSizeColorAttribute(color: UIColor, string: String, size: CGFloat) {
        self.setBoldFontSizeAttribute(size: size, string: string)
        self.setBoldAttribute(string: string)
        self.setColorAttribute(color: color, string: string)
    }
    
    ///特定の文字列をBoldに変更する
    func setBoldAttribute(string: String) {
        self.setAttribute(attribute: [NSAttributedString.Key(rawValue: NSAttributedString.Key.font.rawValue): UIFont.boldSystemFont(ofSize: self.font.pointSize)], string: string)
    }
    
    ///特定の文字列のサイズを変更する(標準フォント)
    func setFontSizeAttribute(size: CGFloat, string: String) {
        self.setAttribute(attribute: [NSAttributedString.Key(rawValue: NSAttributedString.Key.font.rawValue): UIFont.systemFont(ofSize: size)], string: string)
    }
    
    ///特定の文字列のサイズを変更し、Boldにする
    func setBoldFontSizeAttribute(size: CGFloat, string: String) {
        self.setAttribute(attribute: [NSAttributedString.Key(rawValue: NSAttributedString.Key.font.rawValue): UIFont.boldSystemFont(ofSize: size)], string: string)
    }
    
    ///特定の文字列に色やBoldを設定する
    private func setAttribute(attribute: [NSAttributedString.Key:Any], string: String) {
        let attributedString = NSMutableAttributedString(attributedString: self.attributedText!)
        for range in self.text!.regMatchToRange(pattern: string) {
            attributedString.addAttributes(attribute, range: range)
            self.attributedText = attributedString
        }
    }
}
