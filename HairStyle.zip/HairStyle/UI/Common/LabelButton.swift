//
//  LabelButton.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/12.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class LabelButton: BaseButton {
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        if let title = self.title(for: .normal) {
            self.setTitle(ls(title), for: .normal)
        }
        self.titleLabel?.textAlignment = .center
    }
    
    override init(imageName: String) {
        super.init(imageName: imageName)
    }
}
