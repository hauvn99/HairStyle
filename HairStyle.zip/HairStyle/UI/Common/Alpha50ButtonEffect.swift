//
//  Alpha50ButtonEffect.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/06/04.
//

import UIKit

//テキストと画像をα50％で表示
class Alpha50ButtonEffect: LabelButton {
    //ハイライト開始
    override func startHilight(sender: UIButton) {
        let parentView = sender.superview!
        for subview in parentView.subviews as [UIView] {
            subview.alpha = 0.5
        }
    }
    
    //ハイライト終了
    override func endHilight(sender: UIButton) {
        let parentView = sender.superview!
        for subview in parentView.subviews as [UIView] {
            subview.alpha = 1
        }
    }
}
