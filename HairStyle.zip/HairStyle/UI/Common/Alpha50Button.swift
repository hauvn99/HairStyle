//
//  Alpha50Button.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/12.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

//ハイライト画像がないボタンで、ハイライト時はalpha=50%
class Alpha50Button: LabelButton {
    //ハイライト開始
    override func startHilight(sender: UIButton) {
        self.alpha = 0.5
    }
    
    //ハイライト終了
    override func endHilight(sender: UIButton) {
        self.alpha = 1
    }
    
    ///無効時はalpha=0.5
    override var isEnabled: Bool {
        get { return super.isEnabled }
        set {
            super.isEnabled = newValue
            self.alpha = newValue ? 1 : 0.5
        }
    }
}
