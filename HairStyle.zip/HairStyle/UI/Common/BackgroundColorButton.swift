//
//  BackgroundColorButton.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/24.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class BackgroundColorButton: UIButton {
    @IBInspectable var highlightedBackgroundColor :UIColor?
    @IBInspectable var nonHighlightedBackgroundColor :UIColor?
    override var isHighlighted :Bool {
        get {
            return super.isHighlighted
        }
        set {
            if newValue {
                self.backgroundColor = highlightedBackgroundColor
            }
            else {
                self.backgroundColor = nonHighlightedBackgroundColor
            }
            super.isHighlighted = newValue
        }
    }
}
