//
//  PinkLabelButton.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/12.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class PinkLabelButton: LabelButton {
    override var isEnabled: Bool {
        get { return super.isEnabled }
        set {
            super.isEnabled = newValue
            self.titleLabel?.alpha = newValue ? 1 : 0.8
        }
    }
}
