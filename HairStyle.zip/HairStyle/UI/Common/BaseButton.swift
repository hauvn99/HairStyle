//
//  BaseButton.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/27.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class BaseButton: UIButton {
    typealias ButtonEvent = ((UIButton) -> ())
    var event: ButtonEvent?
    var startHilightedEvent: ButtonEvent?
    var endHilightedEvent: ButtonEvent?

    init(imageName: String) {
        let image = UIImage(named: imageName)!
        super.init(frame: ViewUtil.frameBySize(size: image.size))
        self.setBackgroundImage(image, for: .normal)
        self.adjustsImageWhenHighlighted = false
        self.commonInit()
    }
    
    convenience init(normal: String, hilighted: String) {
        self.init(imageName: normal)
        self.setBackgroundImage(UIImage(named: hilighted), for: .highlighted)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    override init(frame: CGRect = .zero) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    //共通初期化処理
    func commonInit() {
        self.addTarget(self, action: #selector(BaseButton.pushed(sender:)), for: .touchUpInside)
        self.addTarget(self, action: #selector(BaseButton.startHilight(sender:)), for: .touchDown)
        self.addTarget(self, action: #selector(BaseButton.endHilight(sender:)), for: .touchUpInside)
        self.addTarget(self, action: #selector(BaseButton.endHilight(sender:)), for: .touchUpOutside)
        self.addTarget(self, action: #selector(BaseButton.endHilight(sender:)), for: .touchCancel)
        self.addTarget(self, action: #selector(BaseButton.pushed(sender:)), for: .touchUpInside)
    }
    
    //押下時イベント、eventとoverride/pushedはpushedが優先
    @objc func pushed(sender: UIButton) {
        self.event?(sender)
    }
    
    //ハイライト開始
    @objc func startHilight(sender: UIButton) {
        self.startHilightedEvent?(sender)
    }

    //ハイライト終了
    @objc func endHilight(sender: UIButton) {
        self.endHilightedEvent?(sender)
    }
}
