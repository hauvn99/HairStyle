//
//  ClearTextField.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/12.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class ClearTextField: BaseTextField {
    private(set) var isEmpty = false
    var emptyText = ls("unset")
    var textfieldType = ""

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.textAlignment = .right
    }
    
    //初期文字列設定
    func setInitialText(text: String?) {
        self.isEmpty = String.noString(string: text)
        if self.isEmpty {
            self.text = self.emptyText
        } else {
            self.text = text
        }
    }
    
    //編集開始
    override func textFieldDidBeginEditing() {
        super.textFieldDidBeginEditing()
        self.textAlignment = .left
        if self.isEmpty {
            self.text = ""
        }
    }
    
    //編集終了
    func textFieldDidEndEditing() {
        self.textAlignment = .right
        self.isEmpty = String.noString(string: self.text)
        if self.isEmpty {
            self.text = self.emptyText
        }
    }
}
