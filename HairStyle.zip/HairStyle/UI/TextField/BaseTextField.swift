//
//  BaseTextField.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/12.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

protocol BaseTextFieldDelegate: class {
    func textFieldDidChange()
}

class BaseTextField: UITextField, TextFieldLockViewManagerDelegate {
    private var scrollOriginalY: CGFloat!
    private var parentScrollView: UIScrollView? { return ViewUtil.parentScrollView(view: self) }
    var isSaveButton = false
    private var keyboardTopView: KeyboardTopView!
    var cancelEvent: (() -> ())? = nil
    var endEvent: (() -> ())? = nil
    weak var baseTextFieldDelegate: BaseTextFieldDelegate?
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        if let placeholder = self.placeholder {
            self.placeholder = ls(placeholder)
        }
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(textFieldDidChange(notification:)), name: UITextField.textDidChangeNotification, object: self)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    ///上部ボタンエリア作成
    func addKeyboardTopView() {
        self.keyboardTopView = KeyboardTopView.create(btnEndTitle: ls(self.isSaveButton ? "dialog_save" : "btn_complete"))
        self.inputAccessoryView = self.keyboardTopView
        if self.isSaveButton {
            self.keyboardTopView.btnCancel.event = { [unowned self] (button) in self.cancelEvent?() }
        } else {
            self.keyboardTopView.btnCancel.removeFromSuperview()
        }
        self.keyboardTopView.btnEnd.event = { [unowned self] (button) in self.endEvent?() }
        self.endEvent = { [unowned self] in self.endEditing(true) }
        self.cancelEvent = { [unowned self] in self.endEditing(true) }
    }
    
    func textFieldDidBeginEditing() {
        self.addKeyboardTopView()
    }
    
    ///決定/保存ボタンの有効無効
    func setEndButtonEnable(isEnable: Bool) {
        self.keyboardTopView.btnEnd.isEnabled = isEnable
    }
    
    ///キーボードが現れた時
    @objc func keyboardWillShow(notification: Notification) {
        if !self.isFirstResponder { return }
        TextFieldLockViewManager.shared.showKeyboard(enableTouchView: self)
        TextFieldLockViewManager.shared.delegate = self
        if self.parentScrollView == nil { return }
        guard let userInfo = notification.userInfo else { return }
        let keyboardFrameEnd = (userInfo[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let curve = UIView.AnimationOptions(rawValue: UInt(truncating: userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] as! NSNumber))
        let duration = TimeInterval(truncating: userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as! NSNumber)
        
        let point = self.superview!.convert(CGPoint(x: 0, y: self.bottom), to: SceneDelegate.shared.window!)
        let diffY =  point.y + 30 - keyboardFrameEnd.origin.y
        if diffY < 0 { return }
        
        if self.scrollOriginalY == nil {
            self.scrollOriginalY = self.parentScrollView!.contentOffset.y
        }
        UIView.animate(withDuration: duration, delay: 0, options: [curve], animations: { [unowned self] in
            self.parentScrollView!.contentOffset.y += diffY
        }, completion: nil)
    }
    
    ///キーボードが消えた時
    @objc func keyboardWillHide(notification: Notification) {
        if !self.isFirstResponder { return }
        TextFieldLockViewManager.shared.hideKeyboard()
        TextFieldLockViewManager.shared.delegate = nil
        if self.parentScrollView == nil { return }
        if self.scrollOriginalY == nil { return }
        guard let userInfo = notification.userInfo else { return }
        let curve = UIView.AnimationOptions(rawValue: UInt(truncating: userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] as! NSNumber))
        let duration = TimeInterval(truncating: userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as! NSNumber)

        let offsetY = max(min(self.scrollOriginalY, self.parentScrollView!.contentSize.height), 0)
        self.scrollOriginalY = nil
        UIView.animate(withDuration: duration, delay: 0, options: [curve], animations: { [unowned self] in
            self.parentScrollView!.contentOffset.y = offsetY
        }, completion: nil)
    }
    
    //テキスト変更
    @objc func textFieldDidChange(notification: NSNotification) {
        let textField = notification.object as! UITextField
        if self === textField {
            self.baseTextFieldDelegate?.textFieldDidChange()
        }
    }
    //TextField以外にTouch
    func onTouchView(sender: Any) {
    self.keyboardTopView.btnEnd.event!(self.keyboardTopView.btnEnd)
    }
}
