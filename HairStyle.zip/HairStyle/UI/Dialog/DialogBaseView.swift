//
//  DialogBaseView.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/09.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

//ダイアログの下地になる拡大するレイヤーと黒いレイヤーを持つ
class DialogBaseView: UIView {
    @IBOutlet weak var blackLayer: UIView!
    @IBOutlet weak var expandLayer: UIView!
    @IBOutlet weak var btnClose: UIButton!
    private(set) var dialog: Dialog!
    var hasExpand = false
    var animatedClosedBtn: Bool = false

    deinit { print("deinit \(String(describing: type(of: self)))") }
    
    ///拡大対象のview
    func setDialogView(dialog: Dialog, expandView: UIView) {
        self.dialog = dialog
        self.btnClose.isHidden = !self.dialog.existsBottomClose
//        self.expandLayer.event = { [unowned self] (button) in
//            if self.hasExpand && self.dialog.enableBlackLayerClose {
//                self.dialog.close(isBlackLayerClose: true)
//            }
//        }
        self.expandLayer.addSubviewCenter(view: expandView)
    }

    ///表示
    func show() {
        if self.dialog.showButtonClose {
            self.btnClose.isHidden = false
        }
        self.animatedClosedBtn = self.dialog.animatedClosedBtn
        DialogManager.shared.show(dialogBaseView: self)
    }

    ///拡大
    func expand() {
        if self.dialog.useStandardExpand {
            self.expandLayer.alpha = 0
            if self.animatedClosedBtn {
                self.dialog.transformScale = 0.6
                self.btnClose.transformScale = 0.5
            } else {
                self.expandLayer.transformScale = 0.8
            }
        }
        UIView.animate(withDuration: self.dialog.expandDuration, animations: {
            self.blackLayer.alpha = 0.7
            if self.dialog.useStandardExpand {
                self.expandLayer.alpha = 1
                if self.animatedClosedBtn {
                    self.dialog.transformScale = 1
                    self.btnClose.transformScale = 1
                } else {
                    self.expandLayer.transformScale = 1
                }
            }
        }, completion: { (completed) in
            self.hasExpand = true
        })
    }

    ///縮小して閉じる
    func close() {
        UIView.animate(withDuration: self.dialog.closeDuration, animations: {
            self.blackLayer.alpha = 0
            if self.dialog.useStandardExpand {
                self.expandLayer.alpha = 0
                if self.animatedClosedBtn {
                    self.dialog.transformScale = 0.8
                    self.btnClose.transformScale = 0.2
                } else {
                    self.expandLayer.transformScale = 0.8
                }
            }
        }, completion: { (completed) in
            DialogManager.shared.dismiss(dialogBaseView: self)
            self.dialog.closeEvent?()
       })
        self.dialog.closeAnimation()
    }
    
    @IBAction func pushedClose(_ sender: Any) {
        self.close()
    }
}
