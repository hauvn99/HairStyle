//
//  Dialog.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/27.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class Dialog: UIView {
    var useStandardExpand: Bool { return true }
    var expandDuration: TimeInterval { return 0.3 }
    var closeDuration: TimeInterval { return 0.3 }
    var existsBottomClose: Bool { return false }
    var showButtonClose: Bool = false
    var animatedClosedBtn: Bool = false
    var closeEvent: Event!
    var enableBlackLayerClose = false
    private(set) var isBlackLayerClose = false
    private weak var dialogBaseView: DialogBaseView!
    private var isClosing = false
    
    deinit {  print("deinit \(String(describing: type(of: self)))") }
    
    ///表示
    func show() {
        self.dialogBaseView = ViewUtil.loadNib(name: "DialogBaseView")
        self.dialogBaseView.setDialogView(dialog: self, expandView: self)
        self.dialogBaseView.show()
    }
    
    ///閉じる
    func close(closeEvent: Event? = nil, isBlackLayerClose: Bool = false) {
        if self.isClosing { return }
        self.isClosing = true
        self.isBlackLayerClose = isBlackLayerClose
        if let closeEvent = closeEvent {
            self.closeEvent = closeEvent
        }
        self.dialogBaseView.close()
    }
    
    ///非表示時のアニメーション
    func closeAnimation() {}
}
