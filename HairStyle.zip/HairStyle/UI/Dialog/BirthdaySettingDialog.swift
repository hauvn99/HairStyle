//
//  BirthdaySettingDialog.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/30.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

protocol BirthdaySettingDialogDelegate: class {
    func onRegister(birthdaySettingDialog: BirthdaySettingDialog, birthday: Birthday)
}

class BirthdaySettingDialog: Dialog {
    
    @IBOutlet weak var lblbirthday: BaseLabel!
    @IBOutlet weak var lblAge: BaseLabel!
    private var birthday: Birthday!
    weak var delegate: BirthdaySettingDialogDelegate?

    static func create(birthday: Birthday, delegate: BirthdaySettingDialogDelegate?) -> BirthdaySettingDialog {
        let dialog: BirthdaySettingDialog = ViewUtil.loadNib(name: "BirthdaySettingDialog")
        dialog.initialize(birthday: birthday, delegate: delegate)
        return dialog
    }
    
    private func initialize(birthday: Birthday, delegate: BirthdaySettingDialogDelegate?) {
        self.birthday = birthday
        self.delegate = delegate
        self.lblbirthday.text = ls("edit_prof_save_birth_date_message", args: self.birthday.date.year, self.birthday.date.month, self.birthday.date.day)
        let attributedString = NSMutableAttributedString.init(attributedString: self.lblbirthday.attributedText!)
        let range = self.lblbirthday.text!.range(of: ls("edit_prof_save_birth_date_date", args: self.birthday.date.year, self.birthday.date.month, self.birthday.date.day))
        attributedString.addAttributes([NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: self.lblbirthday.font.pointSize)], range: range)
        self.lblbirthday.attributedText = attributedString
        self.lblAge.exchangeByArg(arg: self.birthday.age)
    }
    
    //キャンセル押下時
    @IBAction func pushedCancel(_ sender: Any) {
        self.close()
    }

    //登録押下時
    @IBAction func pushedRegister(_ sender: Any) {
        self.delegate?.onRegister(birthdaySettingDialog: self, birthday: self.birthday)
        self.close()
    }
}
