//
//  OKDialog.swift
//  AppMarrish
//
//  Created by nguyen thi ngoc hau on 2020/05/27.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class OKDialog: Dialog {
    
    @IBOutlet weak var lblMsg: UILabel!
    @IBOutlet weak var btnOK: BaseButton!
    ///生成
    static func create(msg: String = ls("dialog_ok_msg"), btnTitle: String = ls("dialog_ok_btn"), event: Event? = nil) -> OKDialog {
        let dialog: OKDialog = ViewUtil.loadNib(name: "OKDialog")
        dialog.initialize(msg: msg, btnTitle: btnTitle, event: event)
        return dialog
    }
    
    ///初期化
    private func initialize(msg: String, btnTitle: String, event: Event?) {
        self.lblMsg.text = msg
        self.btnOK.setTitle(btnTitle, for: .normal)
        self.btnOK.event = { [unowned self] button in
            self.close(closeEvent: event)
        }
    }
}
