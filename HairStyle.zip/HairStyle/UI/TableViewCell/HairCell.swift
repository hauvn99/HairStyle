//
//  HairCell.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/06/01.
//

import UIKit

protocol HairCellDelegate: class {
    //func onPushedMatching(sender: HairCell, member: HairItemData)
    //func onPushedProfile(sender: HairCell, index: Int)
}

class HairCell: UITableViewCell, CircleViewDelegate, HairViewDelegate {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var colorStackView: UIStackView!
    @IBOutlet weak var hairStackView: UIStackView!
    private var data: HairItemData!
    private weak var delegate: HairCellDelegate?
    let hairData: HairData = HairData.init()
    var index: Int = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func config(delegate: HairCellDelegate, data: HairItemData) {
        self.data = data
        self.delegate = delegate
        self.renderView()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func renderView() {
        //self.imgView.image = UIImage(named: self.data.photoUrl)
        self.imgView.image = UIImage(named: self.hairData.hairWomen[self.index].photoUrl)
        
        //colorView
        self.colorStackView.removeSubView()
        for i in 0..<self.hairData.colors.count {
            let itemView = CircleView.create(delegate: self, index: i, width: 20.0, backgroundColor: hairData.colors[i])
            self.colorStackView.addArrangedSubview(itemView)
        }
        
        //bottomView
        self.hairStackView.removeSubView()
        for i in 0..<self.hairData.hairWomen.count {
            let itemView = HairView.create(delegate: self, data: self.hairData.hairWomen[i], index: i)
            self.hairStackView.addArrangedSubview(itemView)
        }
    }
    
    ///CircleViewDelegate
    func pushedButton(sender: CircleView, index: Int) {
        self.index = index
        self.imgView.image = UIImage(named: self.hairData.hairMen[self.index].photoUrl)
    }
    
    ///HairViewDelegate
    func pushedButton(sender: HairView, index: Int) {
        self.index = index
        self.imgView.image = UIImage(named: self.hairData.hairWomen[self.index].photoUrl)
    }
}
