//
//  BaseTextView.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/18.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

protocol BaseTextViewDelegate: class {
    func textViewDidChange()
}

class BaseTextView: UITextView {
    private var scrollOriginalY: CGFloat!
    private var parentScrollView: UIScrollView? { return ViewUtil.parentScrollView(view: self) }
    private var keyboardTopView: KeyboardTopView!
    var endEvent: Event!
    weak var baseTextViewDelegate: BaseTextViewDelegate?
    var placeholder: String!
    private var existsText = false
    
    override var text: String! {
        get { return self.existsText ? super.text : "" }
        set {
            super.text = newValue
            if !self.isFirstResponder {
                self.checkPlaceholder()
            }
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        if let placeholder = self.placeholder {
            self.placeholder = ls(placeholder)
        }
        self.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        self.tintColor = Color.pink
        self.autocorrectionType = .no
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(textViewDidChange(notification:)), name: UITextView.textDidChangeNotification, object: self)
        self.addKeyboardTopView()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    //上部ボタンエリア作成
    func addKeyboardTopView() {
        self.keyboardTopView = KeyboardTopView.create(btnEndTitle: ls("btn_complete"))
        self.inputAccessoryView = self.keyboardTopView
        self.keyboardTopView.btnCancel.removeFromSuperview()
        self.keyboardTopView.btnEnd.event = { [unowned self] (button) in self.endEvent?() }
        self.endEvent = { [unowned self] in self.endEditing(true) }
    }
    
    //プレースホルダーチェック
    func checkPlaceholder() {
        if super.text.isEmpty {
            self.existsText = false
            super.text = self.placeholder
            self.textColor = Color.gray
        } else {
            self.existsText = true
            self.textColor = Color.darkGrayishPurple
        }
    }
    
    func textFieldDidBeginEditing() {
        if !self.existsText {
            super.text = ""
            self.textColor = Color.darkGrayishPurple
        }
    }
    
    func textFieldDidEndEditing() {
        self.existsText = self.text.hasLength
        self.checkPlaceholder()
    }
    
    // キーボードが現れた時
    @objc func keyboardWillShow(notification: Notification) {
        if !self.isFirstResponder { return }
        TextFieldLockViewManager.shared.showKeyboard(enableTouchView: self)
        if self.parentScrollView == nil { return }
        guard let userInfo = notification.userInfo else { return }
        let keyboardFrameEnd = (userInfo[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let curve = UIView.AnimationOptions(rawValue: UInt(truncating: userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] as! NSNumber))
        let duration = TimeInterval(truncating: userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as! NSNumber)
        
        let point = self.superview!.convert(CGPoint(x: 0, y: self.bottom), to: SceneDelegate.shared.window!)
        let diffY =  point.y + 30 - keyboardFrameEnd.origin.y
        if diffY < 0 { return }
        if self.scrollOriginalY == nil {
            self.scrollOriginalY = self.parentScrollView!.contentOffset.y
        }
        UIView.animate(withDuration: duration, delay: 0, options: [curve], animations: { [unowned self] in
            self.parentScrollView!.contentOffset.y += diffY
            }, completion: nil)
    }
    
    // キーボードが消えた時
    @objc func keyboardWillHide(notification: Notification) {
        if !self.isFirstResponder { return }
        TextFieldLockViewManager.shared.hideKeyboard()
        if self.parentScrollView == nil { return }
        if self.scrollOriginalY == nil { return }
        guard let userInfo = notification.userInfo else { return }
        let curve = UIView.AnimationOptions(rawValue: UInt(truncating: userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] as! NSNumber))
        let duration = TimeInterval(truncating: userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as! NSNumber)
        
        let offsetY = max(min(self.scrollOriginalY, self.parentScrollView!.contentSize.height), 0)
        self.scrollOriginalY = nil
        UIView.animate(withDuration: duration, delay: 0, options: [curve], animations: { [unowned self] in
            self.parentScrollView!.contentOffset.y = offsetY
            }, completion: nil)
    }
    
    //テキスト変更
    @objc func textViewDidChange(notification: NSNotification) {
        let textView = notification.object as! UITextView
        if self === textView {
            self.existsText = super.text.hasLength
            self.baseTextViewDelegate?.textViewDidChange()
        }
    }
}
