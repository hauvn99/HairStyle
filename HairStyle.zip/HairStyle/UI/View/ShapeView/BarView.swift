//
//  BarView.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/06/02.
//

import UIKit

class BarView: UIView {
    
    @IBOutlet weak var btnView: UIButton!
    @IBOutlet weak var widthConstraint: NSLayoutConstraint!
    @IBOutlet weak var heightConstraint: NSLayoutConstraint!
    
    private var activeStatus: Bool!
    
    //生成
    static func create(activeStatus: Bool=false, width: CGFloat=25, height: CGFloat=10) -> BarView {
        let view: BarView = ViewUtil.loadNib(name: "BarView")
        view.initialize(activeStatus: activeStatus, width: width, height: height)
        return view
    }

    //初期化
    func initialize(activeStatus: Bool, width: CGFloat, height: CGFloat) {
        self.activeStatus = activeStatus
        self.widthConstraint.constant = width
        self.heightConstraint.constant = height
        self.renderView()
    }
    
    private func renderView() {
        if self.activeStatus {
            self.active()
        } else {
            self.inactive()
        }
    }
    
    func active() {
        self.btnView.backgroundColor = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0)
    }
    
    func inactive() {
        self.btnView.backgroundColor = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 0.4)
    }
}
