//
//  CircleView.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/06/02.
//

import UIKit

protocol CircleViewDelegate: class {
    func pushedButton(sender: CircleView,
                      index: Int)
}

class CircleView: UIView {
    @IBOutlet weak var btnView: LabelButton!
    @IBOutlet weak var widthConstraint: NSLayoutConstraint!
    @IBOutlet weak var heightConstraint: NSLayoutConstraint!
    private var index: Int!
    private weak var delegate: CircleViewDelegate?
    //生成
    static func create(delegate: CircleViewDelegate, index: Int, width: CGFloat=20, backgroundColor: UIColor) -> CircleView {
        let view: CircleView = ViewUtil.loadNib(name: "CircleView")
        view.initialize(delegate: delegate, index: index, width: width, backgroundColor: backgroundColor)
        return view
    }

    //初期化
    func initialize(delegate: CircleViewDelegate, index: Int, width: CGFloat, backgroundColor: UIColor) {
        self.delegate = delegate
        self.index = index
        self.widthConstraint.constant = width
        self.heightConstraint.constant = width
        self.cornerRadius = width/2
        self.renderView(backgroundColor: backgroundColor)
    }
    
    private func renderView(backgroundColor: UIColor) {
        self.btnView.borderColor = backgroundColor
        self.btnView.backgroundColor = backgroundColor
        
        self.btnView.startHilightedEvent = { [unowned self] (btn) in
            btn.alpha = 0.4
        }
        self.btnView.endHilightedEvent = { [unowned self] (btn) in
            btn.alpha = 1
        }
    }
    
    @IBAction func pushedButton(_ sender: Any) {
        self.delegate?.pushedButton(sender: self,
                                    index: self.index)
    }
}
