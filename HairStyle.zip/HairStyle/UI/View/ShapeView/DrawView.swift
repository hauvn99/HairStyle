//
//  DrawView.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/06/02.
//

import UIKit
@IBDesignable
class CirCleButton: UIButton {
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(frame: CGRect = .zero) {
        super.init(frame: frame)
        
    }
    
    func changeInit(width: CGFloat = 20.0, color: UIColor) {
        self.frame = CGRect.init(x: 0, y: 0, width: width, height: width)
        self.width = width
        self.height = width
        self.cornerRadius = width/2
        self.backgroundColor = color
        self.borderColor = color
    }
}

class CirCleShapeView: UIButton {
    
    override func draw(_ rect: CGRect) {
        var path = UIBezierPath()
        path = UIBezierPath(ovalIn: CGRect(x: 50, y: 50, width: 100, height: 100))
        UIColor.yellow.setStroke()
        UIColor.red.setFill()
        path.lineWidth = 5
        path.stroke()
        path.fill()
    }
}
