//
//  CdnImageView.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/11.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

protocol CdnImageViewDelegate : class {
    ///APIから画像データを取得できた時のイベント
    func loaded(imageView: CdnImageView)
}

class CdnImageView: BaseImageView, HttpConnectionDelegate {
    var con : HttpConnection!
    var url : String!
    var loadHasError: Bool =  false
    weak var delegate : CdnImageViewDelegate?
    var clearBeforeLoad = true
    var indicatorView: IndicatorView?
    
    func load(url: String, isGet: Bool = true) {
        if url.isEmpty { return }
        self.url = url
        self.con?.cancel()
        
        if self.clearBeforeLoad {
            self.image = nil
        }
        self.con = HttpConnection.init(urlString: self.url, timeoutInterval: AppConst.apiTimeoutInterval, isGet: isGet)
        self.con.httpConnectionDelegate = self
        self.con.connect()
        self.indicatorView?.show()
    }
    
    ///成功時
    func onSuccess(httpConnection: HttpConnection, responseData: Data) {
        self.image = UIImage(data: responseData)
        if self.image == nil { return }
        CdnImageView.setCache(key: self.url, image: self.image!)
        self.loadHasError = false
        self.delegate?.loaded(imageView: self)
        self.removeIndicator()
    }
    
    ///失敗時
    func onError(httpConnection: HttpConnection) {
        self.removeIndicator()
        self.loadHasError = true
    }
    
    ///インジケータ削除
    private func removeIndicator() {
        self.indicatorView?.remove()
        self.indicatorView = nil
    }
    
    ///以下、キャッシュデータ
    static var chache = [String:UIImage]()

    private static func getNameFromUrl(url:String) -> String {
        let getparam = url.components(separatedBy: "?")
        var keyname = ""
        let getname = getparam[0].components(separatedBy: "/")
        if getname.count > 0 {
            keyname = getname[(getname.count-1)]
        }
        return keyname
    }
    ///画像データをキャッシュから取得する
    static func getCache(key: String) -> UIImage? {
        let keyname = getNameFromUrl(url: key)
        if CdnImageView.chache[keyname] != nil {
            debugLog("find!");
        } else {
            debugLog("not found!");
        }
        return CdnImageView.chache[keyname]
    }
    
    ///画像データをキャッシュする
    private static func setCache(key: String, image: UIImage) {
        let keyname = getNameFromUrl(url: key)
        if CdnImageView.existsCache(key: keyname) { debugLog("key none \(keyname)"); return }
        CdnImageView.chache[keyname] = image
    }
    
    ///画像データがキャッシュに存在するか
    static func existsCache(key: String) -> Bool {
        return CdnImageView.getCache(key: key) != nil
    }
}
