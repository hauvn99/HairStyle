//
//  BaseImageView.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/08/24.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class BaseImageView: UIImageView {
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init(imageName: String) {
        super.init(image: UIImage(named: imageName))
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func changeImage(imageName: String) {
        self.image = UIImage(named: imageName)
    }
}
