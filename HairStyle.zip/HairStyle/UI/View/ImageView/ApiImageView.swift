//
//  ApiImageView.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/03.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

protocol ApiImageViewDelegate : class {
    ///APIから画像データを取得できた時のイベント
    func loaded(imageView: ApiImageView)
}

class ApiImageView: BaseImageView, HttpConnectionDelegate {
    var con : HttpConnection!
    var url : String!
    var loadHasError: Bool =  false
    weak var delegate : ApiImageViewDelegate?
    var clearBeforeLoad = true
    var indicatorView: IndicatorView?
    
    func load(url: String, isGet: Bool = true) {
        if url.isEmpty { return }
        self.url = url
        self.con?.cancel()
        
        if ApiImageView.existsCache(key: self.url) {
            self.image = ApiImageView.getCache(key: self.url)
            self.loadHasError = false
            self.delegate?.loaded(imageView: self)
        } else {
            if self.clearBeforeLoad {
                self.image = nil
            }
            self.con = HttpConnection.init(urlString: self.url, timeoutInterval: AppConst.apiTimeoutInterval, isGet: isGet)
            self.con.httpConnectionDelegate = self
            self.con.connect()
            self.indicatorView?.show()
        }
    }
    
    func loadWithDomain(url: String, isGet: Bool = true) {
        if url.hasPrefix("silhouette_") || url.hasPrefix("/assets/img/silhouette_") {
            var silhoette = url.replacingOccurrences(of:"silhouette_f", with:"silhouette_woman")
            if !silhoette.hasSuffix("silhouette_man.png"){
                silhoette = silhoette.replacingOccurrences(of:"silhouette_m", with:"silhouette_man")
            }
            self.image = UIImage(named: silhoette)
            if self.image == nil {
                return
            } else {
                self.loadHasError = false
                self.delegate?.loaded(imageView: self)
                return
            }
        }
        self.load(url: url, isGet: isGet)
    }

    ///成功時
    func onSuccess(httpConnection: HttpConnection, responseData: Data) {
        self.image = UIImage(data: responseData)
        if self.image == nil { return }
        ApiImageView.setCache(key: self.url, image: self.image!)
        self.loadHasError = false
        self.delegate?.loaded(imageView: self)
        self.removeIndicator()
    }

    ///失敗時
    func onError(httpConnection: HttpConnection) {
        self.removeIndicator()
        self.loadHasError = true
        // urlStringがcdnだったら、再取得API(ファイル名)を呼び出す
        self.image = UIImage(named: LoginUserInfoManager.shared.getPartnerSilhoette())
        if self.image == nil {
            return
        } else {
            self.delegate?.loaded(imageView: self)
            return
        }
    }

    ///インジケータ削除
    private func removeIndicator() {
        self.indicatorView?.remove()
        self.indicatorView = nil
    }
    
    ///以下、キャッシュデータ
    static var chache = [String:UIImage]()
    // imageIdを保存して、mainSearchAPIをrefreshする時に、chacheデータのcacheIdを削除する。
    static var cacheId = [String]()

    private static func getNameFromUrl(url:String) -> String
    {
        let getparam = url.components(separatedBy: "?")
        var keyname = ""
        let getname = getparam[0].components(separatedBy: "/")
        if getname.count > 0 {
            keyname = getname[(getname.count-1)]
        }
        return keyname
    }
    ///画像データをキャッシュから取得する
    private static func getCache(key: String) -> UIImage? {
        let keyname = getNameFromUrl(url: key)
        if ApiImageView.chache[keyname] != nil {
            debugLog("find!");
        } else {
            debugLog("not found!");
        }
        debugLog("key count is \(chache.count) \n\n\n")
        for cachekey in chache.keys {
            debugLog("\(cachekey)");
        }
        return ApiImageView.chache[keyname]
    }

    ///画像データをキャッシュする
    private static func setCache(key: String, image: UIImage) {
        let keyname = getNameFromUrl(url: key)

        if ApiImageView.existsCache(key: keyname) {
            //debugLog("key none \(keyname)");
            return
        }
        ApiImageView.chache[keyname] = image
    }
    
    ///画像データがキャッシュに存在するか
    private static func existsCache(key: String) -> Bool {
        return ApiImageView.getCache(key: key) != nil
    }
    
    ///メモリ警告時にキャッシュを削除する
    static func deleteCacheOnMemoryWarning() {
        ApiImageView.chache.removeAll()
        ApiImageView.cacheId.removeAll()
        #if !RELEASE
            OKDialog.create(msg: "画像のキャッシュをクリアしました\n※このダイアログはリリースモード以外で表示されます").show()
        #endif
    }
    
    static func allCashImageForData(anylist :AnyObject,cacheImage :ApiImageView,delegate :ApiImageViewDelegate){
//        if anylist is MainSearchProfileData {
//            for member in (anylist as! MainSearchProfileData).searchMembers! {
//                if member.membersId != nil {
//                    cacheImage.delegate = delegate
//                    addImageIdToSave(url: member.titlePhotoUrl!)
//                    cacheImage.loadWithDomain(url: member.titlePhotoUrl!)
//                }
//            }
//        }
//        if anylist is SimpleSearchProfileData {
//            for member in (anylist as! SimpleSearchProfileData).searchMembers! {
//                cacheImage.delegate = delegate
//                addImageIdToSave(url: member.titlePhotoUrl!)
//                cacheImage.loadWithDomain(url: member.titlePhotoUrl!)
//            }
//        }
    }
    static func addImageIdToSave(url: String) {
        if url.hasPrefix("silhouette_") || url.hasPrefix("/assets/img/silhouette_") {
          return
        } else {
            let keyname = getNameFromUrl(url: url)
            if !ApiImageView.cacheId.contains(keyname) {
                ApiImageView.cacheId.append(keyname)
            }
        }
    }
    static func removeAllCacheIdImage() {
        for item in ApiImageView.cacheId {
            ApiImageView.chache.removeValue(forKey: item)
        }
        ApiImageView.cacheId.removeAll()
    }
}
