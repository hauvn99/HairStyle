//
//  UserImageView.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/12/03.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class UserImageView: ApiImageView {
    private var userImageUrl: UserImageUrl!

    func load(url: UserImageUrl) {
        self.userImageUrl = url
        if self.userImageUrl.isSilhouette || self.userImageUrl.isWithdraw {
            self.changeSilhouette()
        } else {
            super.loadWithDomain(url: self.userImageUrl.url)
        }
    }
    
    // プロフ写真のシルエット変更
    func EditProfilePhotoLoad(url: UserImageUrl) {
        self.userImageUrl = url
        if self.userImageUrl.isSilhouette || self.userImageUrl.isWithdraw {
             self.changeProfileEditSilhouette()
         } else {
             super.loadWithDomain(url: self.userImageUrl.url)
         }
    }
    
    ///URL設定
    func setUrl(url: UserImageUrl) {
        self.userImageUrl = url
    }
    
    ///再読み込み
    func reload() {
        guard let userImageUrl = self.userImageUrl else { return }
        self.load(url: userImageUrl)
    }
    
    ///シルエット画像に変更
    func changeSilhouette() {
        guard let userImageUrl = self.userImageUrl else { return }
        guard let isMale = userImageUrl.isMale else { return }
        self.image = UIImage(named: isMale ? "silhouette_man" : "silhouette_woman")
    }
    
    // プロフ編集のシルエット画像を変更
    func changeProfileEditSilhouette() {
        guard let userImageUrl = self.userImageUrl else { return }
        guard let isMale = userImageUrl.isMale else { return }
        self.image = UIImage(named: isMale ? "profile_edit_nophoto_man" : "profile_edit_nophoto_woman")
    }
}
