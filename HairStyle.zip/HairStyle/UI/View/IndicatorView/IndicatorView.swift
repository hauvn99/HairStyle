//
//  IndicatorView.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/12.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

enum acIndicatorType {
    case noLock
    case lock
}

struct acIndicatorInfo {
    var type: acIndicatorType
    var view: UIView
}

class IndicatorView: UIView {
    private let expandRate = 0.2.cgf
    private let expandDuration: TimeInterval = 0.3
    @IBOutlet weak var imageView: UIImageView!
    private var parentView: UIView!
    private var isLock: Bool!
    private var existsImage: Bool!
    static private var usingIndicator = [UIView:Int]()
    
    ///共用、標準インジケータを使用するフラグ
    static let standardIndicatorFlg = IndicatorView.create(isLock: true, parentView: IndicatorManager.shared.view)
    ///共用、画像なしロックだけのインジケータフラグ
    static let lockOnlyIndicatorFlg = IndicatorView.create(isLock: true, parentView: IndicatorManager.shared.view, existsImage: false)
    ///共用、写真アップロード関連のインジケーターフラグ(背景がColor.black70)
    static let photoUploadIndicatorFlag = IndicatorView.create(isLock: true, parentView: IndicatorManager.shared.view, color: Color.black50)
   ///インジケータの作成
    static func create(isLock: Bool, parentView: UIView, existsImage: Bool = true, color:UIColor = UIColor.clear) -> IndicatorView {
        let view: IndicatorView = ViewUtil.loadNib(name: "IndicatorView")
        view.initialize(isLock: isLock, parentView: parentView, existsImage: existsImage, color: color)
        return view
    }
    
    ///標準インジケータ作成
    static func createStandard() -> IndicatorView {
        return IndicatorView.create(isLock: true, parentView: IndicatorManager.shared.view)
    }
    ///初期化
    func initialize(isLock: Bool, parentView: UIView, existsImage: Bool, color: UIColor) {
        self.backgroundColor = color
        self.isLock = isLock
        self.parentView = parentView
        self.existsImage = existsImage
        self.frame = ViewUtil.scaleToFillFrame(view: self.parentView)
        self.isUserInteractionEnabled = self.isLock
    }
    
    ///表示
    func show() {
        guard let parentView = self.parentView else { return }
        if IndicatorView.usingIndicator[parentView] == nil {
            ViewUtil.normalizeViewHierarchy()
            parentView.addSubview(self)
            if parentView === IndicatorManager.shared.view {
                parentView.isUserInteractionEnabled = self.isLock
            }
            self.imageView.isHidden = !self.existsImage
            self.expand()
            self.animation()
            IndicatorView.usingIndicator[parentView] = 1
        } else {
            IndicatorView.usingIndicator[parentView]! += 1
        }
    }
    
    ///拡大
    private func expand() {
        self.imageView.alpha = 0
        self.imageView.transformScale = self.expandRate
        UIView.animate(withDuration: self.expandDuration, animations: {
            self.imageView.alpha = 1
            self.imageView.transformScale = 1
        })
    }
    
    ///回転アニメーション
    private func animation() {
        let animation = CABasicAnimation(keyPath: "transform.rotation.z")
        animation.fromValue = 0
        animation.toValue = CGFloat(2 * Double.pi)
        animation.duration = 0.8
        animation.repeatCount = MAXFLOAT
        animation.isRemovedOnCompletion = false
        self.imageView.layer.add(animation, forKey: "animation")
    }
    
    ///非表示アニメーション
    func remove() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
            if IndicatorView.usingIndicator[self.parentView] == nil { return }
            IndicatorView.usingIndicator[self.parentView]! -= 1
            if IndicatorView.usingIndicator[self.parentView]! == 0 {
                IndicatorManager.shared.view.isUserInteractionEnabled = false
                IndicatorView.usingIndicator[self.parentView] = nil
                UIView.animate(withDuration: self.expandDuration, animations: {
                    self.imageView.alpha = 0
                    self.imageView.transformScale = self.expandRate
                }, completion: { (completed) in
                    if IndicatorView.usingIndicator[self.parentView] == nil {
                        self.imageView.layer.removeAllAnimations()
                        self.removeFromSuperview()
                    }
                })
            }
        }
    }
}
