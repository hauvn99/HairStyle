//
//  HairItemView.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/03/03.
//

//https://app.zeplin.io/project/5bff6e36deb27b0175fe43b0/screen/5e7c5eafd707f3856659d254        Profile List
//https://app.zeplin.io/project/5bff6e36deb27b0175fe43b0/screen/60339e3305e8f9113bb24bb9        あしあと
//https://app.zenhub.com/workspaces/accoa-workspace-5cf0d115689f9c7a4ead9551/issues/newbeescoltd/accoa_backlog/562  みてね
import UIKit

protocol HairItemViewDelegate: class {
//    func onPushedMatching(sender: NiceCell, member: NiceCellData)
//    func onPushedProfile(sender: NiceCell, index: Int)
}

class HairItemView: UITableViewCell {
    
//    @IBOutlet weak var imgProfile: ApiImageView!
//    @IBOutlet weak var lblWithdrawn: BaseLabel!
//    @IBOutlet weak var lblName: UILabel!
//    @IBOutlet weak var lblAgePref: UILabel!
//    @IBOutlet weak var commonView: UIView!
//    @IBOutlet weak var cameraView: UIView!
//    @IBOutlet weak var lblCommonCount: UILabel!
//    @IBOutlet weak var lblPhotoCount: UILabel!
//    @IBOutlet weak var messageItem: UIView!
//    @IBOutlet weak var textView: UIView!
//    @IBOutlet weak var blockMessageView: UIView!
//    @IBOutlet weak var lblNiceMessage: UILabel!
//    @IBOutlet weak var onlineMark: UIImageView!
//    @IBOutlet weak var lblJob: UILabel!
//    @IBOutlet weak var lblHoliday: UILabel!
//    @IBOutlet weak var lblHeight: UILabel!
//    @IBOutlet weak var lblPurpose: UILabel!
//    @IBOutlet weak var spaceViewForWithdrawn: UIView!
//    @IBOutlet weak var btnView: UIView!
//    @IBOutlet weak var btnBlockMessage: LabelButton!
    private var data: HairItemData!
    private var index: Int!
    private weak var delegate: HairItemViewDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func config(delegate: HairItemViewDelegate, data: HairItemData, index: Int) {
        self.data = data
        self.index = index
        self.delegate = delegate
        
        self.renderView()
    }
    
    func renderView() {
        // profile view
//        self.lblName.text = self.data.nickname
//        self.lblAgePref.text = ls("profile_age_and_address", args:self.data.age, self.data.prefName )
//        self.lblWithdrawn.isHidden = !self.data.isStatusWithdraw
//        self.spaceViewForWithdrawn.isHidden = !self.data.isStatusWithdraw
//        if self.data.isStatusWithdraw {
//            self.imgProfile.image = UIImage(named: "silhouette_man")
//            self.btnView.isHidden = true
//        } else {
//            self.imgProfile.loadWithDomain(url: self.data.profPhotoUrl)
//            self.btnView.isHidden = false
//        }
//
//        switch self.data.loginStatus {
//        case 0: //24時間以内
//            self.onlineMark.isHidden = false
//            self.onlineMark.image = UIImage(named: "mark_login_time_d18")
//        case 1: //10分以内
//            self.onlineMark.isHidden = false
//            self.onlineMark.image = UIImage(named: "mark_online_d18")
//        default:
//            self.onlineMark.isHidden = true
//        }
//        if self.data.hobbyCommonCnt > 0 {
//            self.commonView.isHidden = false
//            self.lblCommonCount.text = self.data.hobbyCommonCnt.string
//        } else {
//            self.commonView.isHidden = true
//        }
//        if self.data.subphotoCnt > 0 {
//            self.cameraView.isHidden = false
//            self.lblPhotoCount.text = self.data.subphotoCnt.string
//
//        } else {
//            self.cameraView.isHidden = true
//        }
//
//        // micemessage view
//        if self.data.niceMessage.isEmpty || self.data.isStatusWithdraw {
//            self.messageItem.isHidden = true
//            self.btnBlockMessage.isHidden = true
//        } else {
//            self.messageItem.isHidden = false
//            if UserData.shared.isAgeCheck {
//                self.blockMessageView.isHidden = true
//                self.textView.isHidden = false
//                self.lblNiceMessage.text = self.data.niceMessage
//                self.btnBlockMessage.isHidden = true
//            } else {
//                self.blockMessageView.isHidden = false
//                self.textView.isHidden = true
//                self.lblNiceMessage.text = ""
//                self.btnBlockMessage.isHidden = false
//            }
//        }
//
//        // info view
//        self.lblJob.text = self.data.jobCategory.isEmpty ? ls("niced_list_hyphen") : self.data.jobCategory
//        self.lblHoliday.text = self.data.holiday.isEmpty ? ls("niced_list_hyphen") : self.data.holiday
//        self.lblHeight.text = self.data.height.isEmpty ? ls("niced_list_hyphen") : self.data.height
//        self.lblPurpose.text = self.data.purpose.isEmpty ? ls("niced_list_hyphen") : self.data.purpose
    }
}
