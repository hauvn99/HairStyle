//
//  HairView.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/06/01.
//

import UIKit

protocol HairViewDelegate: class {
    func pushedButton(sender: HairView, index: Int)
}

class HairView: UIView {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var btnView: Alpha50ButtonEffect!
    
    private var data: HairItemData!
    private var index: Int!
    private weak var delegate: HairViewDelegate?
    
    //生成
    static func create(delegate: HairViewDelegate, data: HairItemData, index: Int) -> HairView {
        let view: HairView = ViewUtil.loadNib(name: "HairView")
        view.initialize(delegate: delegate, data: data, index: index)
        return view
    }

    //初期化
    func initialize(delegate: HairViewDelegate, data: HairItemData, index: Int) {
        self.data = data
        self.index = index
        self.delegate = delegate
        
        self.renderView()
    }
    
    func renderView() {
        self.imgView.image = UIImage(named: self.data.photoUrl)
    }
    
    @IBAction func pushedButton(_ sender: Any) {
        self.delegate?.pushedButton(sender: self,
                                    index: self.index)
    }
}
