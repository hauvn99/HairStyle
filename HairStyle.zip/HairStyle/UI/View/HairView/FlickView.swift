//
//  FlickView.swift
//  HairStyle
//
//  Created by nguyen thi ngoc hau on 2021/06/04.
//

import UIKit

protocol FlickViewDelegate: class {
    //func pushedButton(sender: HairView, index: Int)
}

class FlickView: UIView {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var effectView: UIView!
    
    private var data: HairItemData!
    private var index: Int!
    private weak var delegate: FlickViewDelegate?
    
    //生成
    static func create(delegate: FlickViewDelegate, data: HairItemData, index: Int, width:CGFloat, height:CGFloat) -> FlickView {
        let view: FlickView = ViewUtil.loadNib(name: "FlickView")
        view.initialize(delegate: delegate, data: data, index: index, width: width, height: height)
        return view
    }

    //初期化
    func initialize(delegate: FlickViewDelegate, data: HairItemData, index: Int, width:CGFloat, height:CGFloat) {
        self.data = data
        self.index = index
        self.delegate = delegate
        self.width = width
        self.height = height
        
        self.layer.masksToBounds = false
        self.layer.shadowColor = Color.darkGrayishPurple.cgColor
        self.layer.masksToBounds = false
        self.layer.shadowOpacity = 0.2
        self.layer.shadowOffset = CGSize(width: 5, height: 5)
        self.layer.cornerRadius = self.cornerRadius
        self.layer.shadowRadius = 8
        
        self.renderView()
    }
    
    func renderView() {
        self.imgView.image = UIImage(named: self.data.photoUrl)
    }
    
    func leftMove(parcent: CGFloat) {
        self.effectView.backgroundColor = Color.white
        self.effectView.alpha = 0.8*parcent
    }
    
    func rightMove(parcent: CGFloat) {
        self.effectView.backgroundColor = Color.pink
        self.effectView.alpha = 0.8*parcent
    }
}
