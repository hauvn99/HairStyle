//
//  KeyboardTopView.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/12.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class KeyboardTopView: UIView {
    
    @IBOutlet weak var btnCancel: Alpha50Button!
    @IBOutlet weak var btnEnd: PinkLabelButton!
    
    static func create(btnEndTitle: String) -> KeyboardTopView {
        let view: KeyboardTopView = ViewUtil.loadNib(name: "KeyboardTopView")
        view.initialize(btnEndTitle: btnEndTitle)
        return view
    }
    
    private func initialize(btnEndTitle: String) {
        self.btnEnd.setTitle(btnEndTitle, for: .normal)
    }
}
