//
//  StandardNavi.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/30.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class StandardNavi: BaseNavi {
    
    static func create() -> StandardNavi { return ViewUtil.loadStoryboardInitialVC(storyboard: "StandardNavi") }

    override func viewDidLoad() {
        super.viewDidLoad()
        //タイトルフォント
        let font = UIFont.createBoldFont(ofSize: 15)
        self.navigationBar.titleTextAttributes = [NSAttributedString.Key.font : font, NSAttributedString.Key.foregroundColor : Color.darkGrayishPurple]
        //下部線
//        let lineHeight = 1.cgf
//        let line = UIView(frame: CGRect(x: 0, y: self.navigationBar.height - lineHeight, width: self.navigationBar.width, height: lineHeight))
//        line.backgroundColor = Color.darkGrayishPurple10
//        self.navigationBar.addSubview(line)
//        self.addUnderLine()
    }
}
