//
//  BaseNavi.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/30.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class BaseNavi: UINavigationController {
    private var underLineView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //デフォルトの下線を消す
        UINavigationBar.appearance().shadowImage = UIImage()
        UINavigationBar.appearance().setBackgroundImage(UIImage(), for: .default)
        //背景色
        self.navigationBar.barTintColor = Color.white
        //透過なし、viewの(0, 0)はnavigationの下になる
        self.navigationBar.isTranslucent = false
    }
    
    func changeNavi(isShow: Bool) {
        if isShow {
            self.addUnderLine()
        } else {
            self.removeUnderLine()
        }
    }
    
    func addUnderLine() {
        //下部線
        let lineHeight = 1.cgf
        self.underLineView?.removeFromSuperview()
        self.underLineView = UIView(frame: CGRect(x: 0, y: self.navigationBar.height - lineHeight, width: self.navigationBar.width, height: lineHeight))
        self.underLineView.backgroundColor = Color.darkGrayishPurple10
        self.navigationBar.addSubview(self.underLineView)
    }
    
    func removeUnderLine() {
        self.underLineView?.removeFromSuperview()
    }
}
