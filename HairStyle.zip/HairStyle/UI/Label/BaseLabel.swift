//
//  BaseLabel.swift
//  AppAocca
//
//  Created by nguyen thi ngoc hau on 2020/06/12.
//  Copyright © 2020 Hau Nguyen. All rights reserved.
//

import UIKit

class BaseLabel: UILabel {
    var attribute: [NSAttributedString.Key:Any]? //InterfaceBuilderでのattribute
    private var textColorNameString: String?

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    convenience init(text: String, color: UIColor, fontSize: CGFloat, weight: CGFloat = UIFont.Weight.regular.rawValue) {
        self.init(frame: CGRect.zero)
        self.textColor = color
        self.font = UIFont.systemFont(ofSize: fontSize, weight: UIFont.Weight(rawValue: weight))
        self.text = text
        self.sizeToFit()
    }

    @IBInspectable var textColorName: String? {
        get {
            return self.textColorNameString
        }
        set {
            self.textColorNameString = newValue
            if let nameString = newValue, let name = Color.Name(rawValue: nameString) {
                self.textColor = Color.from(name: name)
            }
        }
    }

    //InterfaceBuilderのattributeを保存
    func commonInit() {
        if self.text!.isEmpty { return }
        self.attribute = self.attributedText?.attributes(at: 0, effectiveRange: nil)
        self.updateAttribute()
    }
    
    ///フォントや色をテキストに反映
    func updateAttribute() {
        super.attributedText = NSAttributedString(string: ls(self.text!), attributes: self.attribute)
    }
    
    ///InterfaceBuilderのattributeを反映させてテキストを変更
    override var text: String? {
        get { return super.text }
        set {
            if newValue == nil {
                super.text = nil
            } else if self.attribute == nil {
                super.text = ls(newValue!)
            } else {
                super.attributedText = NSAttributedString(string: ls(newValue!), attributes: self.attribute)
            }
        }
    }
    
    ///色変更
    override var textColor: UIColor! {
        get { return super.textColor }
        set {
            if self.attribute == nil {
                super.textColor = newValue
            } else {
                self.attribute![NSAttributedString.Key.foregroundColor] = newValue
                self.updateAttribute()
            }
        }
    }
    
    ///文字列の中の変換部分を変換
    func exchangeByArg(arg: Any...) {
        self.text = LocalizeManager.shared.exchangeArg(str: self.text!, args: arg)
    }
}
